# ==============================================================================
# utils/config.py
# ------------------------------------------------------------------------------
# WHAT THIS FILE DOES:
#   Centralizes all configuration in one place. Every other module in this
#   project imports settings (API keys, model names, folder paths, etc.) from
#   here instead of reading environment variables directly.
#
# WHY THIS MATTERS (GenAI beginners):
#   RAG apps have a LOT of "knobs" you'll want to tune while experimenting:
#     - which LLM to call
#     - which embedding model to use
#     - how big each text chunk should be
#     - how many chunks to retrieve per question
#   Putting them all in one Config object means you can tune the whole
#   pipeline's behavior by editing ONE file (or even just the .env file)
#   instead of hunting through every .py file for a hard-coded number.
# ==============================================================================

import os
from dataclasses import dataclass
from dotenv import load_dotenv

# load_dotenv() reads the ".env" file in the project root and copies its
# key=value pairs into the process's environment variables (os.environ).
# This keeps secrets (like API keys) OUT of the source code.
load_dotenv()


@dataclass
class Config:
    """
    A simple, typed container for all app settings.

    Using a dataclass (instead of scattering os.getenv() calls everywhere)
    gives us:
      - autocomplete / type hints in your editor
      - one obvious place to see every setting the app depends on
      - easy defaults if a .env value is missing
    """

    # --- OpenAI credentials & model choices ---------------------------------
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    chat_model: str = os.getenv("OPENAI_CHAT_MODEL", "gpt-4o")
    embedding_model: str = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-large")

    # --- Vector store (ChromaDB) settings ------------------------------------
    chroma_persist_dir: str = os.getenv("CHROMA_PERSIST_DIR", "data/chroma_db")
    chroma_collection_name: str = os.getenv("CHROMA_COLLECTION_NAME", "aetna_insurance_docs")

    # --- Chunking settings ----------------------------------------------------
    # CHUNK_SIZE: how many characters go into each chunk of text.
    # CHUNK_OVERLAP: how many characters two consecutive chunks share, so a
    #                sentence that spans a chunk boundary isn't lost entirely.
    chunk_size: int = int(os.getenv("CHUNK_SIZE", 1000))
    chunk_overlap: int = int(os.getenv("CHUNK_OVERLAP", 200))

    # --- Retrieval settings -----------------------------------------------------
    # RETRIEVAL_TOP_K: how many of the most-similar chunks we hand to the LLM
    # as context for each question.
    retrieval_top_k: int = int(os.getenv("RETRIEVAL_TOP_K", 5))

    # --- File storage paths -------------------------------------------------
    pdf_upload_dir: str = os.getenv("PDF_UPLOAD_DIR", "data/pdfs")

    def validate(self) -> None:
        """
        Raise a clear, human-readable error early if required settings are
        missing, instead of letting the app crash later with a cryptic
        "401 Unauthorized" deep inside the OpenAI SDK.
        """
        if not self.openai_api_key or self.openai_api_key.startswith("sk-REPLACE"):
            raise ValueError(
                "OPENAI_API_KEY is not set. Copy .env.example to .env and add "
                "your real OpenAI API key before running the app."
            )


# A single, shared Config instance that every other module can import:
#     from utils.config import settings
settings = Config()
