# ==============================================================================
# app.py
# ------------------------------------------------------------------------------
# PROJECT ENTRY POINT.
#
# HOW TO RUN THIS APP:
#       streamlit run app.py
#
# WHAT THIS FILE DOES:
#   This file is intentionally tiny. Its only job is to import and launch
#   the actual UI code that lives in frontend/streamlit_ui.py. Keeping
#   app.py minimal (rather than putting all the UI logic directly here)
#   makes the project easier to navigate: anyone opening the repo can see
#   at a glance that the "front door" is app.py, while the real
#   implementation is organized by responsibility into ingestion/,
#   chunking/, embeddings/, vectorstore/, retrieval/, rag/, prompts/, and
#   frontend/.
#
# WHY A SEPARATE frontend/streamlit_ui.py INSTEAD OF PUTTING EVERYTHING HERE:
#   Streamlit runs whatever .py file you pass to `streamlit run` as a
#   script from top to bottom. Separating the UI into its own module means
#   you could, in principle, later add a second frontend (e.g., a FastAPI
#   backend for a different UI) that reuses the same rag/, retrieval/, etc.
#   modules without duplicating any pipeline logic.
# ==============================================================================

import frontend.streamlit_ui  # noqa: F401  (import runs run_app() automatically)
