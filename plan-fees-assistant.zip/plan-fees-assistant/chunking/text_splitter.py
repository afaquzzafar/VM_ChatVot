# ==============================================================================
# chunking/text_splitter.py
# ------------------------------------------------------------------------------
# STEP 3 of the RAG pipeline: "Chunk documents"
#
# WHAT THIS FILE DOES:
#   Breaks each page's text into smaller overlapping "chunks" of text that
#   are small enough to (a) embed cheaply and (b) fit comfortably inside an
#   LLM prompt alongside a few other chunks.
#
# WHY CHUNKING IS NECESSARY (GenAI beginners):
#     1. Embedding models and LLMs have limited context windows — you can't
#        cram a 300-page policy document into one API call.
#     2. Similarity search works best on FOCUSED pieces of text — smaller,
#        focused chunks retrieve more accurately for a specific question.
#
# WHY OVERLAP BETWEEN CHUNKS:
#   If a sentence gets cut in half by a hard chunk boundary, neither
#   resulting chunk contains the complete fact. Overlapping the end of one
#   chunk with the start of the next greatly reduces the odds of splitting
#   an important fact in two.
#
# SECTION/SUBSECTION-AWARE CHUNKING — HOW IT WORKS, AND WHY IT'S FAST:
#   Plan/regulatory documents (EOC, SBC, Medicare Managed Care Manual) are
#   structured into numbered/titled sections and subsections, and it's
#   genuinely useful to know which one a chunk came from (better citations,
#   better filtering during evaluation). An earlier version of this module
#   implemented that by pre-slicing each page into one SEGMENT per detected
#   header and running the splitter once per segment — but that meant every
#   header found on a page forced at least one extra chunk boundary, so a
#   densely-subsectioned document (a Medicare manual page can carry a
#   dozen "10.1 / 10.1.1 / 10.1.2 ..." headings) produced far more, far
#   smaller chunks than plain character-count chunking ever would — several
#   times as many embedding calls for the same document, which is exactly
#   what made ingestion slow.
#
#   This version fixes that by decoupling "where headers are" from "where
#   chunk boundaries are":
#     Pass 1 — scan the page ONCE for header lines and record, at each
#              header's character offset, what the (section, subsection)
#              context becomes from that offset onward. This never changes
#              how many chunks get produced — it's pure bookkeeping.
#     Pass 2 — run LangChain's RecursiveCharacterTextSplitter over the
#              WHOLE page exactly once, precisely like plain character
#              chunking. Chunk count therefore depends only on
#              chunk_size/chunk_overlap, never on how many headers a page
#              happens to contain.
#     Pass 3 — label each resulting chunk with the nearest PRECEDING
#              header's section/subsection (an O(log headers) lookup per
#              chunk), so citations still read "(Source: eoc.pdf, page 14,
#              Section 4.1 Prior Authorization)" — the metadata is just as
#              rich, it's simply attached after chunking instead of driving
#              it.
#
#   Header context is carried forward across pages within the same source
#   document, since a section frequently spans multiple PDF pages. If a
#   page has no detectable headers at all, every chunk on it just inherits
#   whatever section/subsection was last seen (or None, on a cover page).
#
# HEADER STYLES RECOGNIZED (tuned against real EOC/SBC/CMS-manual samples):
#   - ALL-CAPS "SECTION 4", "PART I:" / Title-case "CHAPTER 9:" — top level.
#     Note "SECTION" must be fully UPPERCASE to count as top-level: some
#     insurance EOCs use ALL-CAPS "SECTION 4" for chapter-level sections and
#     Title-case "Section 4.1" for its subsections — those two forms differ
#     ONLY by case, so matching "SECTION" case-insensitively would silently
#     swallow every subsection heading as if it were a new top-level
#     section (which is what the earlier version of this file did).
#   - Title-case "Section 4.1", "Section 4.1.2" (keyword + a DECIMAL
#     number) — subsection, distinguished from the bullet above by the
#     required decimal point.
#   - Bare numbered, no keyword at all — the CMS Medicare Managed Care
#     Manual style: "10 – Introduction" (top level, no decimal, dash
#     required so an ordinary sentence starting with a number isn't
#     misread as a header) and "10.1 – General Requirements" /
#     "110.1.2.1 – General" (subsection, one to four decimal levels deep).
#   - Bare ALL-CAPS topic headers, e.g. "COVERED SERVICES" (SBC style).
# ==============================================================================

import bisect
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_text_splitters import RecursiveCharacterTextSplitter

from ingestion.pdf_loader import PageContent
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class Chunk:
    """
    A single chunk of text, ready to be embedded, along with the metadata
    it inherited from its source page (filename + page number) plus the
    section/subsection heading it falls under, if any.
    """

    text: str
    metadata: dict = field(default_factory=dict)
    chunk_id: str = ""  # assigned by DocumentChunker, e.g. "eoc.pdf_p14_c3"


# ------------------------------------------------------------------------------
# Header detection patterns. These are deliberately conservative (favor
# missing an occasional header over mis-classifying ordinary body text as
# one) — a missed header just means a chunk inherits the PREVIOUS header's
# label, which is the same thing plain character chunking would've given
# you anyway, so there's no downside to a miss. See the module docstring
# above for why each pattern looks the way it does.
# ------------------------------------------------------------------------------

# Top-level chapter/part headers. Safe to match case-insensitively: no
# observed document style uses "CHAPTER N.M" / "PART N.M" as a subsection
# form, so there's no ambiguity to guard against here the way there is for
# "SECTION" below.
_CHAPTER_HEADER_RE = re.compile(
    r"^(?:CHAPTER|ARTICLE|PART)\s+(?:[0-9]{1,3}[A-Za-z]?|[IVXLCDM]{1,6})\b"
    r"[:.\-–]?\s*.*$",
    re.IGNORECASE,
)

# Top-level "SECTION 4" — the keyword MUST be fully uppercase. This is
# case-SENSITIVE on purpose (see module docstring): Title-case "Section
# 4.1" is a SUBSECTION in the same documents, not another top-level section.
_SECTION_ALLCAPS_HEADER_RE = re.compile(r"^SECTION\s+[0-9]{1,3}[A-Z]?\b[:.\-–]?\s*.*$")

# Subsection "Section 4.1", "Section 4.1.2" — Title-case keyword + a
# DECIMAL number is what distinguishes this from the ALL-CAPS pattern above.
_SECTION_SUBSECTION_RE = re.compile(r"^Section\s+\d{1,3}(?:\.\d{1,3}){1,3}\b[:.\-–]?\s*.*$")

# Bare numbered subsection, no keyword — CMS-manual style:
# "10.1 – General Requirements", "110.1.2.1 – General" (up to 4 levels).
_BARE_SUBSECTION_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){1,4}\s*[\-–]?\s*(?=.*[A-Za-z])\S.*$")

# Bare numbered top-level section, no keyword — CMS-manual style:
# "10 – Introduction". No decimal point (that's the pattern above) and a
# dash separator is required so an ordinary line starting with a number
# isn't misread as a header.
_BARE_SECTION_RE = re.compile(r"^\d{1,3}\s*[\-–]\s+(?=.*[A-Za-z])\S.*$")

# Bare ALL-CAPS topic headers common in SBC-style documents, e.g.
# "COVERED SERVICES", "WHAT YOU WILL PAY"
_ALLCAPS_CHARSET_RE = re.compile(r"^[A-Z0-9][A-Z0-9 &,'/\-()]*[A-Z0-9)]$")

_MAX_HEADER_LINE_LEN = 90

# Table-of-contents entries ("SECTION 1  What to do if you have a problem
# or concern                                   39") use the exact same
# "SECTION N <title>" text as the real header later in the document, so the
# patterns above can't tell them apart by wording alone. What DOES tell
# them apart: PDF-to-text extraction preserves the dot-leader/tab alignment
# as a run of whitespace immediately before the trailing page number, which
# a real header line never has (found by inspecting the actual EOC PDF's
# table of contents vs. its in-body chapter headers). Any candidate header
# line ending in "<2+ spaces><1-4 digit number>" is treated as a ToC entry,
# not a real header, and skipped.
_TOC_TRAILING_PAGE_NUMBER_RE = re.compile(r"\s{2,}\d{1,4}$")
_MAX_HEADER_WORD_COUNT = 12


def _looks_like_allcaps_header(line: str) -> bool:
    """Heuristic check for a short, title-like, all-uppercase header line."""
    if not (4 <= len(line) <= _MAX_HEADER_LINE_LEN):
        return False
    if len(line.split()) > _MAX_HEADER_WORD_COUNT:
        return False
    if not any(c.isalpha() for c in line):
        return False
    if any(c.islower() for c in line):
        return False
    return bool(_ALLCAPS_CHARSET_RE.match(line))


def _classify_line(stripped_line: str) -> Optional[str]:
    """Returns "section", "subsection", or None for one stripped line of page text."""
    if not stripped_line or len(stripped_line) > _MAX_HEADER_LINE_LEN:
        return None
    if _TOC_TRAILING_PAGE_NUMBER_RE.search(stripped_line):
        return None
    if _CHAPTER_HEADER_RE.match(stripped_line):
        return "section"
    if _SECTION_ALLCAPS_HEADER_RE.match(stripped_line):
        return "section"
    if _SECTION_SUBSECTION_RE.match(stripped_line):
        return "subsection"
    if _BARE_SUBSECTION_RE.match(stripped_line):
        return "subsection"
    if _BARE_SECTION_RE.match(stripped_line):
        return "section"
    if _looks_like_allcaps_header(stripped_line):
        return "section"
    return None


@dataclass
class _HeadingCheckpoint:
    """The (section, subsection) context effective from `offset` onward."""

    offset: int
    section: Optional[str]
    subsection: Optional[str]


def _find_heading_checkpoints(
    page_text: str,
    current_section: Optional[str],
    current_subsection: Optional[str],
) -> Tuple[List[_HeadingCheckpoint], Optional[str], Optional[str]]:
    """
    Scan a page ONCE for header lines and record a checkpoint at each one.
    This is pure bookkeeping for chunk labeling — it does NOT influence how
    the page gets split (see DocumentChunker.chunk_pages), so detecting
    more headers never produces more chunks.

    Returns (checkpoints sorted by offset ascending — always at least one,
    for offset 0 — section_at_end_of_page, subsection_at_end_of_page) so
    the caller can thread context into the next page of the same document.
    """
    checkpoints = [_HeadingCheckpoint(0, current_section, current_subsection)]
    section, subsection = current_section, current_subsection
    offset = 0

    for line in page_text.split("\n"):
        kind = _classify_line(line.strip())
        if kind == "section":
            section, subsection = line.strip(), None
            checkpoints.append(_HeadingCheckpoint(offset, section, subsection))
        elif kind == "subsection":
            subsection = line.strip()
            checkpoints.append(_HeadingCheckpoint(offset, section, subsection))
        offset += len(line) + 1  # +1 accounts for the "\n" consumed by split("\n")

    return checkpoints, section, subsection


class DocumentChunker:
    """
    Wraps LangChain's RecursiveCharacterTextSplitter with insurance-document
    friendly defaults. Chunking is size-based and runs ONCE per page — chunk
    (and therefore embedding-call) count depends only on chunk_size /
    chunk_overlap, never on how many section/subsection headers a page
    happens to contain. Header detection is used only to LABEL each
    resulting chunk with the section/subsection it falls under.
    """

    def __init__(self, chunk_size: int = None, chunk_overlap: int = None):
        # Fall back to the values from utils/config.py (which itself falls
        # back to .env, which falls back to sensible hard-coded defaults).
        self.chunk_size = chunk_size or settings.chunk_size
        self.chunk_overlap = chunk_overlap or settings.chunk_overlap

        # separators are tried IN ORDER — LangChain first tries to split on
        # "\n\n" (paragraph breaks). Only if a chunk is still too long does
        # it move down the list to smaller and smaller split points.
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            separators=["\n\n", "\n", ". ", " ", ""],
            length_function=len,
        )

        logger.info(
            f"DocumentChunker initialized (chunk_size={self.chunk_size}, "
            f"chunk_overlap={self.chunk_overlap}, section-aware=True)"
        )

    def chunk_pages(self, pages: List[PageContent]) -> List[Chunk]:
        """
        Split every page's text into chunks, preserving source/page
        metadata plus the nearest section/subsection heading on each chunk.

        Args:
            pages: List of PageContent objects from ingestion/pdf_loader.py
                   (optionally already PHI/PII-masked by
                   ingestion/pii_masking.py — this function doesn't care
                   either way, it just chunks whatever text it's given).

        Returns:
            A flat list of Chunk objects across all input pages.
        """
        all_chunks: List[Chunk] = []

        # Track section/subsection context PER SOURCE DOCUMENT, since a
        # single chunk_pages() call may process pages from several PDFs and
        # each document's heading structure is independent of the others.
        current_section: Dict[str, Optional[str]] = {}
        current_subsection: Dict[str, Optional[str]] = {}

        for page in pages:
            doc_key = page.source_file

            checkpoints, section_at_end, subsection_at_end = _find_heading_checkpoints(
                page.text, current_section.get(doc_key), current_subsection.get(doc_key)
            )
            current_section[doc_key] = section_at_end
            current_subsection[doc_key] = subsection_at_end
            checkpoint_offsets = [cp.offset for cp in checkpoints]

            # ONE splitter pass over the whole page — same cost as plain
            # character-count chunking, regardless of how many headers
            # were found above.
            text_pieces = self.splitter.split_text(page.text)

            search_from = 0
            for i, piece in enumerate(text_pieces):
                idx = page.text.find(piece, search_from)
                if idx == -1:
                    # Defensive fallback — every returned piece should be a
                    # verbatim substring of the page text, but never let an
                    # offset lookup miss crash ingestion over a labeling detail.
                    idx = search_from
                search_from = idx + 1  # guarantees forward progress even with overlap

                checkpoint_index = max(bisect.bisect_right(checkpoint_offsets, idx) - 1, 0)
                checkpoint = checkpoints[checkpoint_index]

                chunk_id = f"{page.source_file}_p{page.page_number}_c{i}"
                all_chunks.append(
                    Chunk(
                        text=piece,
                        metadata={
                            **page.metadata,
                            "chunk_index_on_page": i,
                            "section": checkpoint.section,
                            "subsection": checkpoint.subsection,
                        },
                        chunk_id=chunk_id,
                    )
                )

        logger.info(f"Split {len(pages)} pages into {len(all_chunks)} chunks")
        return all_chunks
