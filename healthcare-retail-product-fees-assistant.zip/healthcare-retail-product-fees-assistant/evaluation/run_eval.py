# ==============================================================================
# evaluation/run_eval.py
# ------------------------------------------------------------------------------
# NEW MODULE — CLI to compute Recall@K, Precision@K, MRR, and NDCG@K for the
# retrieval pipeline against a small hand-labeled "golden" dataset.
#
# USAGE:
#     python -m evaluation.run_eval --dataset data/eval/golden_dataset.json --k 5
#
#     # Compare configurations (e.g. does MQR/reranking actually help?):
#     python -m evaluation.run_eval --no-mqr --no-rerank --report baseline.json
#     python -m evaluation.run_eval --report hybrid_mqr_rerank.json
#
# THE GOLDEN DATASET FORMAT (see data/eval/golden_dataset.json):
#     [
#       {
#         "question": "What is the annual individual deductible?",
#         "relevant_chunk_ids": ["Plan_EOC_2026.pdf_p14_s2_c0"]
#       },
#       ...
#     ]
#
# `relevant_chunk_ids` must use the SAME id scheme
# chunking/text_splitter.py assigns as `Chunk.chunk_id`
# ("<source_file>_p<page>_s<segment>_c<index>"), which is also the id each
# chunk is stored under in ChromaDB. After ingesting your real documents,
# run `python -m evaluation.build_golden_dataset_template` to dump every
# stored chunk_id + a text preview, so you can hand-pick the right ids for
# each of your evaluation questions instead of guessing them.
# ==============================================================================

import argparse
import json
import sys

from embeddings.embedding_service import EmbeddingService
from evaluation.metrics import evaluate_retrieval
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.multi_query import MultiQueryRetriever
from retrieval.reranker import CrossEncoderReranker
from vectorstore.chroma_manager import ChromaManager
from utils.logger import get_logger

logger = get_logger(__name__)


def _load_dataset(path: str) -> list:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_retrieve_fn(use_mqr: bool, use_reranker: bool):
    """
    Wires up the retrieval stack directly (bypassing RAGPipeline/the LLM
    entirely when MQR is disabled) so retrieval quality can be measured
    on its own, independent of chat-provider configuration.
    """
    embedding_service = EmbeddingService()
    chroma_manager = ChromaManager(embedding_service=embedding_service)
    hybrid_retriever = HybridRetriever(chroma_manager)

    llm = None
    if use_mqr:
        # Multi-query needs an LLM to generate paraphrases; reuse whichever
        # chat provider is already configured (same provider/auth logic as
        # rag/rag_pipeline.py — untouched here).
        from utils.config import settings

        if settings.chat_provider == "databricks":
            from langchain_databricks import ChatDatabricks

            llm = ChatDatabricks(endpoint=settings.databricks_chat_endpoint, temperature=0)
        elif settings.chat_provider == "openai" and settings.has_openai_key:
            from langchain_openai import ChatOpenAI

            llm = ChatOpenAI(model=settings.chat_model, temperature=0, openai_api_key=settings.openai_api_key)
        else:
            logger.warning("No chat provider configured — running evaluation without Multi-Query Retrieval")

    multi_query_retriever = MultiQueryRetriever(hybrid_retriever, llm=llm)
    reranker = CrossEncoderReranker()

    def retrieve_fn(question: str, k: int):
        candidates = multi_query_retriever.retrieve(question, top_k=max(k * 4, 20))
        if use_reranker:
            return reranker.rerank(question, candidates, top_k=k)
        return candidates[:k]

    return retrieve_fn, chroma_manager


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate the retrieval pipeline (Recall@K, Precision@K, MRR, NDCG@K) "
        "against a golden question -> relevant-chunk-ids dataset."
    )
    parser.add_argument("--dataset", default="data/eval/golden_dataset.json")
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--no-mqr", action="store_true", help="Disable Multi-Query Retrieval for this run")
    parser.add_argument("--no-rerank", action="store_true", help="Disable cross-encoder reranking for this run")
    parser.add_argument("--report", default=None, help="Optional path to write a full JSON report")
    args = parser.parse_args()

    try:
        dataset = _load_dataset(args.dataset)
    except FileNotFoundError:
        logger.error(
            f"Golden dataset not found at '{args.dataset}'. See data/eval/golden_dataset.json "
            f"for the expected format and data/eval/README.md for how to build your own."
        )
        sys.exit(1)

    if not dataset:
        logger.error(f"'{args.dataset}' contains no evaluation queries")
        sys.exit(1)

    retrieve_fn, chroma_manager = build_retrieve_fn(use_mqr=not args.no_mqr, use_reranker=not args.no_rerank)

    if chroma_manager.document_count() == 0:
        logger.error(
            "The vector store is empty — run backend ingestion "
            "(python -m ingestion.ingest_cli <pdf paths>) before evaluating retrieval."
        )
        sys.exit(1)

    result = evaluate_retrieval(dataset, retrieve_fn, k=args.k)

    print(f"\nRetrieval evaluation @ K={result.k} over {len(dataset)} quer(ies) "
          f"(MQR={'on' if not args.no_mqr else 'off'}, rerank={'on' if not args.no_rerank else 'off'}):")
    print(f"  Recall@{result.k}:    {result.recall_at_k:.3f}")
    print(f"  Precision@{result.k}: {result.precision_at_k:.3f}")
    print(f"  MRR:          {result.mrr:.3f}")
    print(f"  NDCG@{result.k}:      {result.ndcg_at_k:.3f}\n")

    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "k": result.k,
                    "use_mqr": not args.no_mqr,
                    "use_reranker": not args.no_rerank,
                    "recall_at_k": result.recall_at_k,
                    "precision_at_k": result.precision_at_k,
                    "mrr": result.mrr,
                    "ndcg_at_k": result.ndcg_at_k,
                    "per_query": result.per_query,
                },
                f,
                indent=2,
            )
        print(f"Full report written to {args.report}")


if __name__ == "__main__":
    main()
