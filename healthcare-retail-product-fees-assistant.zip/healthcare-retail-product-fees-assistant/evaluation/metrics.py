# ==============================================================================
# evaluation/metrics.py
# ------------------------------------------------------------------------------
# NEW MODULE — Retrieval evaluation metrics: Recall@K, Precision@K, MRR,
# and NDCG@K.
#
# WHY EVALUATE RETRIEVAL AT ALL (GenAI beginners):
#   The original codebase had zero automated way to answer "did we just
#   make retrieval better or worse?" — the only tests covered chunking
#   mechanics and prompt string assembly, never whether the RIGHT chunks
#   actually come back for a given question. Once you're combining several
#   retrieval strategies (BM25 + vector + multi-query + reranking), you
#   need a repeatable, numeric way to compare them — that's what this
#   module is for. See evaluation/run_eval.py for the CLI that runs these
#   metrics against a small hand-labeled "golden" dataset.
#
# METRIC DEFINITIONS (all computed per-query, then averaged):
#   Recall@K    — of ALL the chunks that are actually relevant to this
#                 question, what fraction did we find in the top K results?
#                 Answers: "are we missing relevant information?"
#   Precision@K — of the K chunks we returned, what fraction were actually
#                 relevant? Answers: "how much noise did we hand the LLM?"
#   MRR         — Mean Reciprocal Rank: 1 / (rank of the FIRST relevant
#                 result), averaged across queries. Rewards putting a
#                 relevant chunk as close to position 1 as possible —
#                 important because the LLM tends to weight earlier context
#                 more heavily.
#   NDCG@K      — Normalized Discounted Cumulative Gain: like Recall, but
#                 rewards relevant results MORE when they appear EARLIER
#                 (logarithmic discount by rank) and supports graded
#                 relevance (not just binary relevant/irrelevant), then
#                 normalizes against the best-possible (ideal) ordering so
#                 scores are comparable across queries with different
#                 numbers of relevant chunks.
# ==============================================================================

import math
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional, Sequence


def recall_at_k(retrieved_ids: Sequence[str], relevant_ids: Iterable[str], k: int) -> float:
    """Fraction of all relevant chunk_ids that appear in the top-K retrieved_ids."""
    relevant_set = set(relevant_ids)
    if not relevant_set:
        return 0.0
    top_k_hits = set(retrieved_ids[:k]) & relevant_set
    return len(top_k_hits) / len(relevant_set)


def precision_at_k(retrieved_ids: Sequence[str], relevant_ids: Iterable[str], k: int) -> float:
    """Fraction of the top-K retrieved_ids that are actually relevant."""
    top_k = list(retrieved_ids[:k])
    if not top_k:
        return 0.0
    relevant_set = set(relevant_ids)
    hits = len(set(top_k) & relevant_set)
    return hits / len(top_k)


def reciprocal_rank(retrieved_ids: Sequence[str], relevant_ids: Iterable[str]) -> float:
    """1 / rank of the first relevant id in retrieved_ids (0.0 if none found)."""
    relevant_set = set(relevant_ids)
    for rank, doc_id in enumerate(retrieved_ids, start=1):
        if doc_id in relevant_set:
            return 1.0 / rank
    return 0.0


def mean_reciprocal_rank(
    retrieved_id_lists: Sequence[Sequence[str]], relevant_id_lists: Sequence[Iterable[str]]
) -> float:
    """MRR averaged across several queries' (retrieved_ids, relevant_ids) pairs."""
    if not retrieved_id_lists:
        return 0.0
    scores = [
        reciprocal_rank(retrieved, relevant)
        for retrieved, relevant in zip(retrieved_id_lists, relevant_id_lists)
    ]
    return sum(scores) / len(scores)


def dcg_at_k(
    ranked_ids: Sequence[str],
    relevant_ids: Iterable[str],
    k: int,
    graded_relevance: Optional[Dict[str, float]] = None,
) -> float:
    """
    Discounted Cumulative Gain over the first k items of ranked_ids.
    Binary relevance (1.0/0.0) unless graded_relevance provides finer-grained
    scores per chunk_id (e.g. 2 = highly relevant, 1 = partially relevant).
    """
    relevant_set = set(relevant_ids)
    dcg = 0.0
    for position, doc_id in enumerate(ranked_ids[:k], start=1):
        if graded_relevance is not None:
            gain = float(graded_relevance.get(doc_id, 0.0))
        else:
            gain = 1.0 if doc_id in relevant_set else 0.0
        if gain:
            dcg += (2**gain - 1) / math.log2(position + 1)
    return dcg


def ndcg_at_k(
    retrieved_ids: Sequence[str],
    relevant_ids: Iterable[str],
    k: int,
    graded_relevance: Optional[Dict[str, float]] = None,
) -> float:
    """NDCG@K = DCG@K of the actual ranking, divided by DCG@K of the ideal (best-possible) ranking."""
    relevant_ids = list(relevant_ids)
    dcg = dcg_at_k(retrieved_ids, relevant_ids, k, graded_relevance)

    if graded_relevance is not None:
        ideal_order = sorted(relevant_ids, key=lambda d: graded_relevance.get(d, 0.0), reverse=True)
    else:
        ideal_order = relevant_ids

    idcg = dcg_at_k(ideal_order, relevant_ids, k, graded_relevance)
    return dcg / idcg if idcg > 0 else 0.0


@dataclass
class RetrievalEvalResult:
    """Aggregate + per-query results from evaluate_retrieval()."""

    k: int
    recall_at_k: float
    precision_at_k: float
    mrr: float
    ndcg_at_k: float
    per_query: List[dict] = field(default_factory=list)


def evaluate_retrieval(
    golden_queries: List[dict],
    retrieve_fn: Callable[[str, int], List],
    k: int = 5,
) -> RetrievalEvalResult:
    """
    Run Recall@K, Precision@K, MRR, and NDCG@K over a labeled dataset.

    Args:
        golden_queries: list of
            {"question": str, "relevant_chunk_ids": [str, ...]}
            entries (optionally "graded_relevance": {chunk_id: score}).
        retrieve_fn: callable(question, k) -> list of objects exposing a
            `.chunk_id` attribute (e.g. retrieval.retriever.RetrievedChunk),
            ordered most-to-least relevant. This is intentionally decoupled
            from any specific retriever class so the SAME metrics can score
            vector-only, BM25-only, hybrid, or hybrid+MQR+rerank results —
            see evaluation/run_eval.py for how each configuration is wired.
        k: cutoff rank for Recall@K / Precision@K / NDCG@K (MRR has no
           cutoff by definition).

    Returns:
        A RetrievalEvalResult with both the averaged metrics and a
        per-query breakdown (useful for spotting which specific questions
        retrieval is failing on).
    """
    per_query = []
    recalls, precisions, reciprocal_ranks, ndcgs = [], [], [], []

    for item in golden_queries:
        question = item["question"]
        relevant_ids = item.get("relevant_chunk_ids", [])
        graded_relevance = item.get("graded_relevance")

        retrieved_chunks = retrieve_fn(question, k)
        retrieved_ids = [getattr(chunk, "chunk_id", None) for chunk in retrieved_chunks]

        r = recall_at_k(retrieved_ids, relevant_ids, k)
        p = precision_at_k(retrieved_ids, relevant_ids, k)
        rr = reciprocal_rank(retrieved_ids, relevant_ids)
        n = ndcg_at_k(retrieved_ids, relevant_ids, k, graded_relevance)

        recalls.append(r)
        precisions.append(p)
        reciprocal_ranks.append(rr)
        ndcgs.append(n)

        per_query.append(
            {
                "question": question,
                "retrieved_ids": retrieved_ids,
                "relevant_ids": list(relevant_ids),
                "recall": r,
                "precision": p,
                "reciprocal_rank": rr,
                "ndcg": n,
            }
        )

    n_queries = len(golden_queries) or 1
    return RetrievalEvalResult(
        k=k,
        recall_at_k=sum(recalls) / n_queries,
        precision_at_k=sum(precisions) / n_queries,
        mrr=sum(reciprocal_ranks) / n_queries,
        ndcg_at_k=sum(ndcgs) / n_queries,
        per_query=per_query,
    )
