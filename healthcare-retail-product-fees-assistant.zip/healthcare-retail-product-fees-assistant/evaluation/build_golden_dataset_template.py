# ==============================================================================
# evaluation/build_golden_dataset_template.py
# ------------------------------------------------------------------------------
# NEW MODULE — helper to bootstrap a golden evaluation dataset for YOUR
# actual ingested documents.
#
# WHY THIS EXISTS:
#   evaluation/run_eval.py needs a hand-labeled dataset mapping questions
#   to the chunk_id(s) that should be retrieved to answer them. Guessing
#   chunk_ids by hand is tedious and error-prone (they encode source file +
#   page + section index + chunk index — see chunking/text_splitter.py).
#   This script dumps every chunk_id currently stored in ChromaDB, along
#   with a short text preview and its source/page/section, so a human
#   reviewer can quickly pick the right id(s) for each evaluation question.
#
# USAGE:
#     python -m evaluation.build_golden_dataset_template --out data/eval/chunk_inventory.json
#
#   Then hand-write data/eval/golden_dataset.json referencing the chunk_ids
#   from that inventory (see data/eval/README.md).
# ==============================================================================

import argparse
import json

from embeddings.embedding_service import EmbeddingService
from vectorstore.chroma_manager import ChromaManager


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Dump every stored chunk's id + preview, to help build a golden eval dataset."
    )
    parser.add_argument("--out", default="data/eval/chunk_inventory.json")
    parser.add_argument("--preview-chars", type=int, default=200)
    args = parser.parse_args()

    chroma_manager = ChromaManager(embedding_service=EmbeddingService())
    documents = chroma_manager.get_all_documents()

    inventory = []
    for chunk_id, document in documents:
        preview = document.page_content[: args.preview_chars]
        inventory.append(
            {
                "chunk_id": chunk_id,
                "source": document.metadata.get("source"),
                "page": document.metadata.get("page"),
                "section": document.metadata.get("section"),
                "subsection": document.metadata.get("subsection"),
                "text_preview": preview,
            }
        )

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(inventory, f, indent=2)

    print(f"Wrote {len(inventory)} chunk(s) to {args.out}")


if __name__ == "__main__":
    main()
