# ==============================================================================
# chunking/text_splitter.py
# ------------------------------------------------------------------------------
# STEP 3 of the RAG pipeline: "Chunk documents"
#
# WHAT THIS FILE DOES:
#   Breaks each page's text into smaller overlapping "chunks" of text that
#   are small enough to (a) embed cheaply and (b) fit comfortably inside an
#   LLM prompt alongside a few other chunks.
#
# WHY CHUNKING IS NECESSARY (GenAI beginners):
#   You might think: "why not just embed each entire PDF page, or the whole
#   document, as one big vector?" Two reasons:
#     1. Embedding models and LLMs have limited context windows — you can't
#        cram a 300-page policy document into one API call.
#     2. Similarity search works best on FOCUSED pieces of text. If a page
#        discusses both "deductibles" and "prior authorization", embedding
#        the whole page as one vector blurs those two topics together,
#        making retrieval less precise. Smaller, focused chunks retrieve
#        more accurately for a specific question.
#
# WHY OVERLAP BETWEEN CHUNKS:
#   If a sentence like "The annual deductible is $1,500 per individual and
#   $3,000 per family" gets cut in half by a hard chunk boundary, neither
#   resulting chunk contains the complete fact. Overlapping the end of one
#   chunk with the start of the next greatly reduces the odds of splitting
#   an important fact in two.
#
# SECTION/SUBSECTION-AWARE CHUNKING (upgrade from plain recursive splitting):
#   Plan documents (EOC/SBC/Medicare Managed Care Manual) are structured
#   into numbered/titled sections and subsections ("SECTION 4: EMERGENCY
#   CARE", "4.1 Prior Authorization", ALL-CAPS topic headers, etc.). Chunking
#   purely by character count ignores that structure and can merge the tail
#   of one topic with the head of an unrelated one, hurting both retrieval
#   precision and citation quality.
#
#   This module now runs a two-pass split:
#     Pass 1 — detect section/subsection headers in the page text and slice
#              the page into header-bounded SEGMENTS (a segment is "the
#              header line + everything under it, until the next header").
#              Header context is carried forward across pages within the
#              same source document, since a section frequently spans
#              multiple PDF pages.
#     Pass 2 — run LangChain's RecursiveCharacterTextSplitter (paragraph ->
#              line -> sentence -> word -> char) WITHIN each segment, so a
#              chunk never silently straddles two unrelated sections, and
#              every chunk's metadata carries the section/subsection title
#              it belongs to — useful both for citations ("Source: eoc.pdf,
#              page 14, Section 4.1 Prior Authorization") and for filtering
#              during evaluation.
#
#   If a page has no detectable headers (common on cover pages, or for
#   plain-text uploads), the whole page is treated as a single segment and
#   behaves exactly like the previous character-based-only splitter.
# ==============================================================================

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_text_splitters import RecursiveCharacterTextSplitter

from ingestion.pdf_loader import PageContent
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class Chunk:
    """
    A single chunk of text, ready to be embedded, along with the metadata
    it inherited from its source page (filename + page number) plus the
    section/subsection heading it was found under, if any. This metadata is
    what allows the final chatbot answer to say
    "(Source: Plan_EOC_2026.pdf, page 14)" and lets evaluation/reporting
    slice results by section.
    """

    text: str
    metadata: dict = field(default_factory=dict)
    chunk_id: str = ""  # assigned by DocumentChunker, e.g. "eoc.pdf_p14_s2_c0"


# ------------------------------------------------------------------------------
# Header detection patterns.
#
# These are deliberately conservative (favor missing an occasional header
# over mis-classifying ordinary body text as one) — a missed header just
# falls back to character-based splitting for that stretch of text, which
# is exactly the previous behavior, so there's no downside to a miss.
# ------------------------------------------------------------------------------

# "SECTION 4: EMERGENCY CARE", "ARTICLE III - GRIEVANCES", "Chapter 5. Appeals"
_SECTION_HEADER_RE = re.compile(
    r"^(?:SECTION|ARTICLE|CHAPTER|PART)\s+(?:[0-9]{1,3}[A-Za-z]?|[IVXLCDM]{1,6})\b"
    r"[:.\-–]?\s*.*$",
    re.IGNORECASE,
)

# "4.1 Prior Authorization", "12.3.1 - Coordination of Benefits"
_SUBSECTION_HEADER_RE = re.compile(
    r"^\d{1,3}(?:\.\d{1,3}){1,3}\s+(?=.*[A-Za-z])\S.*$"
)

# Bare ALL-CAPS topic headers common in SBC-style documents, e.g.
# "COVERED SERVICES", "WHAT YOU WILL PAY", "IMPORTANT INFORMATION"
_ALLCAPS_CHARSET_RE = re.compile(r"^[A-Z0-9][A-Z0-9 &,'/\-()]*[A-Z0-9)]$")

_MAX_HEADER_LINE_LEN = 90
_MAX_HEADER_WORD_COUNT = 12


def _looks_like_allcaps_header(line: str) -> bool:
    """Heuristic check for a short, title-like, all-uppercase header line."""
    if not (4 <= len(line) <= _MAX_HEADER_LINE_LEN):
        return False
    if len(line.split()) > _MAX_HEADER_WORD_COUNT:
        return False
    if not any(c.isalpha() for c in line):
        return False
    if any(c.islower() for c in line):
        return False
    return bool(_ALLCAPS_CHARSET_RE.match(line))


def _classify_line(stripped_line: str) -> Optional[str]:
    """
    Returns "section", "subsection", or None for a single (already-stripped)
    line of page text.
    """
    if not stripped_line or len(stripped_line) > _MAX_HEADER_LINE_LEN:
        return None
    if _SECTION_HEADER_RE.match(stripped_line):
        return "section"
    if _SUBSECTION_HEADER_RE.match(stripped_line):
        return "subsection"
    if _looks_like_allcaps_header(stripped_line):
        return "section"
    return None


@dataclass
class _Segment:
    section: Optional[str]
    subsection: Optional[str]
    text: str


def _split_page_into_segments(
    page_text: str,
    current_section: Optional[str],
    current_subsection: Optional[str],
) -> Tuple[List[_Segment], Optional[str], Optional[str]]:
    """
    Slice one page's text into header-bounded segments, carrying forward
    whatever section/subsection context was active at the end of the
    PREVIOUS page of the same document (sections routinely span pages).

    Returns (segments, section_at_end_of_page, subsection_at_end_of_page)
    so the caller can thread context into the next page.
    """
    segments: List[_Segment] = []
    section = current_section
    subsection = current_subsection
    buffer: List[str] = []

    def flush() -> None:
        if buffer:
            text = "\n".join(buffer).strip()
            if text:
                segments.append(_Segment(section=section, subsection=subsection, text=text))
            buffer.clear()

    for line in page_text.split("\n"):
        kind = _classify_line(line.strip())
        if kind == "section":
            flush()
            section = line.strip()
            subsection = None  # a new top-level section resets subsection context
            buffer.append(line)
        elif kind == "subsection":
            flush()
            subsection = line.strip()
            buffer.append(line)
        else:
            buffer.append(line)

    flush()
    return segments, section, subsection


class DocumentChunker:
    """
    Section/subsection-aware chunker: slices each page into header-bounded
    segments, then wraps LangChain's RecursiveCharacterTextSplitter (with
    insurance-document friendly defaults) to size chunks within each
    segment, preserving page-level AND section-level metadata through the
    split.
    """

    def __init__(self, chunk_size: int = None, chunk_overlap: int = None):
        # Fall back to the values from utils/config.py (which itself falls
        # back to .env, which falls back to sensible hard-coded defaults).
        self.chunk_size = chunk_size or settings.chunk_size
        self.chunk_overlap = chunk_overlap or settings.chunk_overlap

        # separators are tried IN ORDER — LangChain first tries to split on
        # "\n\n" (paragraph breaks). Only if a chunk is still too long does
        # it move down the list to smaller and smaller split points.
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            separators=["\n\n", "\n", ". ", " ", ""],
            length_function=len,
        )

        logger.info(
            f"DocumentChunker initialized (chunk_size={self.chunk_size}, "
            f"chunk_overlap={self.chunk_overlap}, section-aware=True)"
        )

    def chunk_pages(self, pages: List[PageContent]) -> List[Chunk]:
        """
        Split every page's text into section-aware chunks, preserving
        source/page/section metadata on each resulting chunk.

        Args:
            pages: List of PageContent objects from ingestion/pdf_loader.py
                   (optionally already PHI/PII-masked by
                   ingestion/pii_masking.py — this function doesn't care
                   either way, it just chunks whatever text it's given).

        Returns:
            A flat list of Chunk objects across all input pages.
        """
        all_chunks: List[Chunk] = []

        # Track section/subsection context PER SOURCE DOCUMENT, since a
        # single chunk_pages() call may process pages from several PDFs
        # (e.g. when multiple files are ingested together) and each
        # document's heading structure is independent of the others.
        current_section: Dict[str, Optional[str]] = {}
        current_subsection: Dict[str, Optional[str]] = {}

        for page in pages:
            doc_key = page.source_file
            segments, section_at_end, subsection_at_end = _split_page_into_segments(
                page.text,
                current_section.get(doc_key),
                current_subsection.get(doc_key),
            )
            current_section[doc_key] = section_at_end
            current_subsection[doc_key] = subsection_at_end

            for segment_index, segment in enumerate(segments):
                # split_text() returns a list of plain strings — the actual
                # splitting logic (paragraph -> sentence -> word -> char)
                # lives inside LangChain's RecursiveCharacterTextSplitter.
                text_pieces = self.splitter.split_text(segment.text)

                for i, piece in enumerate(text_pieces):
                    chunk_id = f"{page.source_file}_p{page.page_number}_s{segment_index}_c{i}"
                    all_chunks.append(
                        Chunk(
                            text=piece,
                            metadata={
                                **page.metadata,
                                "chunk_index_on_page": i,
                                "section": segment.section,
                                "subsection": segment.subsection,
                            },
                            chunk_id=chunk_id,
                        )
                    )

        logger.info(f"Split {len(pages)} pages into {len(all_chunks)} chunks")
        return all_chunks
