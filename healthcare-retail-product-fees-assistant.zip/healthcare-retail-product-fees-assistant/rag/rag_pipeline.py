# ==============================================================================
# rag/rag_pipeline.py
# ------------------------------------------------------------------------------
# This is the ORCHESTRATOR entry point for the whole pipeline. It exposes
# just two methods to callers (the Streamlit chat UI, and the backend
# ingestion CLI):
#     ingest_documents(file_paths) -> runs backend-only ingestion:
#         extract text -> mask PHI/PII -> section-aware chunk -> embed ->
#         store in ChromaDB -> refresh the BM25 keyword index
#     ask(question) -> runs the LangGraph question-answering path:
#         guardrail -> Multi-Query Retrieval (hybrid BM25+vector) ->
#         cross-encoder rerank -> grounded LLM answer -> suggested
#         follow-up questions
#
# WHAT IS "RAG" IN ONE SENTENCE? (GenAI beginners)
#   Retrieval-Augmented Generation = instead of asking an LLM to answer
#   purely from what it memorized during training, we first RETRIEVE the
#   most relevant snippets of TRUSTED, up-to-date documents, and then ask
#   the LLM to GENERATE an answer using ONLY those snippets.
#
# WHAT CHANGED FROM THE ORIGINAL SINGLE-VECTOR-SEARCH PIPELINE:
#   - Retrieval is now HYBRID (BM25 keyword search + vector search, fused
#     with Reciprocal Rank Fusion) instead of vector-only — see
#     retrieval/hybrid_retriever.py.
#   - Retrieval runs Multi-Query Retrieval (a few LLM-generated paraphrases
#     of the question, merged) before reranking — see
#     retrieval/multi_query.py.
#   - A cross-encoder reranks the fused candidate pool down to the final
#     top-K used in the prompt — see retrieval/reranker.py.
#   - The whole retrieve -> rerank -> generate -> suggest-followups flow is
#     now a LangGraph StateGraph with an up-front prompt-injection
#     guardrail — see orchestration/graph.py.
#   - Ingestion now masks PHI/PII (see ingestion/pii_masking.py) BEFORE
#     chunking, and rebuilds the BM25 index after every ingest so keyword
#     search always reflects what's actually in the vector store.
#
# WHAT DID NOT CHANGE:
#   - How the chat/embedding provider and API keys are configured
#     (utils/config.py's openai_api_key / has_openai_key / validate(), and
#     the chat_provider="databricks" vs "openai" branching below) is
#     untouched, per explicit instruction not to alter authentication or
#     API key handling.
# ==============================================================================

from dataclasses import dataclass, field
from typing import List

from chunking.text_splitter import DocumentChunker
from embeddings.embedding_service import EmbeddingService
from guardrails.prompt_injection import PromptInjectionGuard
from ingestion.pdf_loader import PDFLoader
from ingestion.pii_masking import mask_pages
from orchestration.graph import build_rag_graph
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.retriever import RetrievedChunk
from vectorstore.chroma_manager import ChromaManager
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class RAGResponse:
    """
    The final answer package returned to the Streamlit frontend: the
    generated text, the exact chunks it was grounded in (for citations),
    and up to settings.max_followup_questions suggested next questions.
    """

    answer: str
    sources: List[RetrievedChunk] = field(default_factory=list)
    followup_questions: List[str] = field(default_factory=list)
    blocked: bool = False


class RAGPipeline:
    """
    The single entry point the Streamlit frontend (and the backend
    ingestion CLI) talk to.
    """

    def __init__(self):
        # --- Shared building blocks, wired together once at startup -------
        self.pdf_loader = PDFLoader()
        self.chunker = DocumentChunker()
        self.embedding_service = EmbeddingService()
        self.chroma_manager = ChromaManager(embedding_service=self.embedding_service)
        self.hybrid_retriever = HybridRetriever(self.chroma_manager)
        self.guard = PromptInjectionGuard()

        # --- LLM initialization — UNCHANGED from the original pipeline ----
        # (do not alter authentication or API key handling)
        self.llm = None
        if settings.chat_provider == "databricks":
            from langchain_databricks import ChatDatabricks

            self.llm = ChatDatabricks(
                endpoint=settings.databricks_chat_endpoint,
                temperature=0,
            )
            logger.info(
                f"RAGPipeline initialized with Databricks LLM "
                f"(endpoint='{settings.databricks_chat_endpoint}')"
            )
        elif settings.chat_provider == "openai" and settings.has_openai_key:
            from langchain_openai import ChatOpenAI

            self.llm = ChatOpenAI(
                model=settings.chat_model,
                temperature=0,
                openai_api_key=settings.openai_api_key,
            )
            logger.info("RAGPipeline initialized with OpenAI LLM")
        else:
            logger.info(
                "RAGPipeline initialized WITHOUT LLM. "
                "Document ingestion is available; chat requires a provider."
            )

        # --- Orchestration graph: guardrail -> MQR/hybrid -> rerank ->
        #     generate -> suggest follow-ups (see orchestration/graph.py) --
        self.graph = build_rag_graph(self.hybrid_retriever, self.llm, guard=self.guard)

        # Keep the retriever attribute name used by the previous version of
        # this class (frontend/streamlit_ui.py and tests referenced
        # `pipeline.retriever.has_documents()`) pointed at the new hybrid
        # retriever so existing callers keep working unchanged.
        self.retriever = self.hybrid_retriever

    # -------------------------------------------------------------------
    # INGESTION (backend-only — see ingestion/ingest_cli.py; there is no
    # upload widget in the Streamlit UI anymore, see frontend/streamlit_ui.py)
    # -------------------------------------------------------------------
    def ingest_documents(self, file_paths: List[str]) -> int:
        """
        Run the full backend ingestion pipeline on a list of PDF file paths
        already saved to disk:
            extract text -> mask PHI/PII -> section-aware chunk ->
            embed + store in ChromaDB -> rebuild the BM25 keyword index

        Args:
            file_paths: paths to PDF files on disk, e.g.
                        ["data/pdfs/Plan_EOC_2026.pdf"]

        Returns:
            The number of chunks successfully embedded and stored.
        """
        logger.info(f"Starting ingestion for {len(file_paths)} file(s)")

        # Step: Extract text from PDFs
        pages = self.pdf_loader.load_multiple_pdfs(file_paths)
        if not pages:
            logger.warning("No text could be extracted from the uploaded PDF(s)")
            return 0

        # Step: Mask PHI/PII BEFORE anything is chunked or embedded, so no
        # raw personal information ever reaches the embedding model, the
        # vector store, the BM25 index, or (via retrieval) the LLM prompt.
        pages = mask_pages(pages)

        # Step: Section/subsection-aware chunking
        chunks = self.chunker.chunk_pages(pages)

        # Step: Generate embeddings & store them in ChromaDB (embedding
        # happens INSIDE add_chunks(), via the embedding_function wired
        # into ChromaManager's Chroma vectorstore)
        stored_count = self.chroma_manager.add_chunks(chunks)

        # Step: Rebuild the BM25 keyword index so hybrid retrieval sees the
        # newly-ingested chunks immediately, not just on next restart.
        self.hybrid_retriever.refresh_bm25_index()

        logger.info(f"Ingestion complete: {stored_count} chunks stored")
        return stored_count

    # -------------------------------------------------------------------
    # QUESTION ANSWERING — runs the LangGraph orchestration path.
    # -------------------------------------------------------------------
    def ask(self, question: str) -> RAGResponse:
        """
        Answer a user's question using only the ingested documents, via:
        prompt-injection guardrail -> Multi-Query + Hybrid retrieval ->
        cross-encoder rerank -> grounded LLM answer -> suggested follow-ups.

        Args:
            question: the user's natural-language question

        Returns:
            A RAGResponse with the answer text, source chunks (for
            citations), and up to N suggested follow-up questions.
        """
        final_state = self.graph.invoke({"question": question})

        return RAGResponse(
            answer=final_state.get("answer", ""),
            sources=final_state.get("final_chunks", []) or [],
            followup_questions=final_state.get("followup_questions", []) or [],
            blocked=bool(final_state.get("blocked", False)),
        )
