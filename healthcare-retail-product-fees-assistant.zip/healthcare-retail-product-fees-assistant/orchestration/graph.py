# ==============================================================================
# orchestration/graph.py
# ------------------------------------------------------------------------------
# NEW MODULE — LangGraph orchestration for the question-answering path.
#
# WHY LANGGRAPH (instead of the previous linear Python function)?
#   The original rag/rag_pipeline.py's ask() was a straight-line function:
#   retrieve -> build prompt -> call LLM -> return. That worked when there
#   was exactly one retrieval step. Now there are several DISTINCT stages
#   with real branching (a blocked question skips retrieval entirely; an
#   empty knowledge base skips reranking/generation entirely) and each
#   stage benefits from being independently testable, loggable, and
#   swappable:
#
#       START
#         |
#         v
#     [guardrail]  --blocked-->  END (refusal, no retrieval/LLM spend)
#         | ok
#         v
#     [retrieve]   --no documents-->  END ("please ingest documents" message)
#         | ok
#         v
#     [rerank]
#         |
#         v
#     [generate]
#         |
#         v
#     [suggest_followups]
#         |
#         v
#        END
#
#   LangGraph models exactly this: a typed, shared State that flows through
#   named nodes connected by (conditional) edges. Compared to hand-rolled
#   if/else chains, it gives us a single place that shows the whole control
#   flow, first-class support for the early-exit branches above, and a
#   natural seam for later additions (e.g. a caching node, a human-review
#   node) without restructuring the rest of the pipeline.
#
# HOW THIS FITS INTO THE BIGGER PICTURE:
#   rag/rag_pipeline.py builds ONE compiled graph (via build_rag_graph)
#   when the RAGPipeline is constructed, and ask() just calls
#   graph.invoke({"question": question}) — so all the retrieval/rerank/
#   guardrail/follow-up wiring lives here, in one auditable place.
# ==============================================================================

from typing import List, Optional, TypedDict

from langgraph.graph import END, START, StateGraph

from guardrails.prompt_injection import PromptInjectionGuard
from prompts.followup_prompt import build_followup_prompt, parse_followup_questions
from prompts.prompt_template import SYSTEM_PROMPT, build_user_prompt
from retrieval.hybrid_retriever import HybridRetriever
from retrieval.multi_query import MultiQueryRetriever
from retrieval.reranker import CrossEncoderReranker
from retrieval.retriever import RetrievedChunk
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class RAGState(TypedDict, total=False):
    """
    Shared state threaded through every node. `total=False` means every key
    is optional — each node only needs to read the keys earlier nodes have
    actually populated, and only writes the keys it's responsible for.
    """

    question: str
    blocked: bool
    block_reason: str
    no_documents: bool
    candidate_chunks: List[RetrievedChunk]
    context_flags: List[dict]
    final_chunks: List[RetrievedChunk]
    answer: str
    followup_questions: List[str]


NO_DOCUMENTS_MESSAGE = (
    "I don't have any plan documents to search yet. Documents are ingested on the "
    "backend (see ingestion/ingest_cli.py) — please make sure ingestion has been run "
    "before asking questions."
)

NO_LLM_MESSAGE = (
    "The chat model isn't configured right now, so I can't generate an answer. "
    "Document retrieval is still working — please check the chat provider "
    "configuration (this does not affect API key/authentication settings)."
)


def build_rag_graph(hybrid_retriever: HybridRetriever, llm, guard: Optional[PromptInjectionGuard] = None):
    """
    Wire the full question-answering path as a compiled LangGraph app.

    Args:
        hybrid_retriever: a retrieval.hybrid_retriever.HybridRetriever
                           already wired to the live ChromaManager/BM25Index.
        llm: a LangChain chat model (or None if no chat provider is
             configured — the graph degrades to NO_LLM_MESSAGE rather than
             crashing, matching the previous pipeline's behavior).
        guard: optional PromptInjectionGuard override, mainly for testing.

    Returns:
        A compiled LangGraph app. Call `.invoke({"question": "..."})` and
        read the returned RAGState's "answer", "final_chunks", and
        "followup_questions" keys.
    """
    guard = guard or PromptInjectionGuard()
    multi_query_retriever = MultiQueryRetriever(hybrid_retriever, llm=llm)
    reranker = CrossEncoderReranker()

    # -- Nodes -----------------------------------------------------------

    def guardrail_node(state: RAGState) -> dict:
        result = guard.check_question(state["question"])
        if result.blocked:
            return {
                "blocked": True,
                "block_reason": result.reason,
                "answer": result.reason,
                "final_chunks": [],
                "followup_questions": [],
            }
        return {"blocked": False}

    def retrieve_node(state: RAGState) -> dict:
        if not hybrid_retriever.has_documents():
            return {
                "no_documents": True,
                "candidate_chunks": [],
                "final_chunks": [],
                "answer": NO_DOCUMENTS_MESSAGE,
                "followup_questions": [],
            }
        candidates = multi_query_retriever.retrieve(state["question"])
        return {"no_documents": False, "candidate_chunks": candidates}

    def rerank_node(state: RAGState) -> dict:
        final_chunks = reranker.rerank(
            state["question"], state.get("candidate_chunks", []), top_k=settings.retrieval_top_k
        )
        context_flags = guard.scan_context(final_chunks)
        return {"final_chunks": final_chunks, "context_flags": context_flags}

    def generate_node(state: RAGState) -> dict:
        if llm is None:
            return {"answer": NO_LLM_MESSAGE}

        from langchain_core.messages import HumanMessage, SystemMessage

        user_prompt = build_user_prompt(
            state["question"], state.get("final_chunks", []), state.get("context_flags", [])
        )
        messages = [SystemMessage(content=SYSTEM_PROMPT), HumanMessage(content=user_prompt)]

        logger.info(
            f"Sending question to LLM with {len(state.get('final_chunks', []))} reranked context chunk(s)"
        )
        ai_message = llm.invoke(messages)
        return {"answer": ai_message.content}

    def suggest_followups_node(state: RAGState) -> dict:
        if not settings.enable_followup_questions or llm is None:
            return {"followup_questions": []}
        try:
            from langchain_core.messages import HumanMessage

            prompt = build_followup_prompt(
                state["question"], state.get("answer", ""), settings.max_followup_questions
            )
            response = llm.invoke([HumanMessage(content=prompt)])
            questions = parse_followup_questions(str(response.content), settings.max_followup_questions)
            return {"followup_questions": questions}
        except Exception as exc:
            logger.warning(f"Follow-up question generation failed (non-fatal): {exc}")
            return {"followup_questions": []}

    # -- Conditional routing -----------------------------------------------

    def route_after_guardrail(state: RAGState) -> str:
        return "blocked" if state.get("blocked") else "continue"

    def route_after_retrieve(state: RAGState) -> str:
        return "no_documents" if state.get("no_documents") else "continue"

    # -- Graph assembly -----------------------------------------------------

    graph = StateGraph(RAGState)
    graph.add_node("guardrail", guardrail_node)
    graph.add_node("retrieve", retrieve_node)
    graph.add_node("rerank", rerank_node)
    graph.add_node("generate", generate_node)
    graph.add_node("suggest_followups", suggest_followups_node)

    graph.add_edge(START, "guardrail")
    graph.add_conditional_edges(
        "guardrail", route_after_guardrail, {"blocked": END, "continue": "retrieve"}
    )
    graph.add_conditional_edges(
        "retrieve", route_after_retrieve, {"no_documents": END, "continue": "rerank"}
    )
    graph.add_edge("rerank", "generate")
    graph.add_edge("generate", "suggest_followups")
    graph.add_edge("suggest_followups", END)

    return graph.compile()
