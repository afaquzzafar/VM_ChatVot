# ==============================================================================
# tests/test_evaluation_metrics.py
# ------------------------------------------------------------------------------
# Unit tests for evaluation/metrics.py (Recall@K, Precision@K, MRR, NDCG@K).
#
# These tests use plain lists of ids rather than real RetrievedChunk/LLM
# calls, so they run instantly with no API key, no vector store, and no
# model downloads required — exactly like tests/test_chunking.py and
# tests/test_prompt_template.py.
#
# HOW TO RUN:
#       pytest tests/test_evaluation_metrics.py -v
# ==============================================================================

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from evaluation.metrics import (
    dcg_at_k,
    evaluate_retrieval,
    mean_reciprocal_rank,
    ndcg_at_k,
    precision_at_k,
    recall_at_k,
    reciprocal_rank,
)


def test_recall_at_k_all_found():
    retrieved = ["a", "b", "c", "d"]
    relevant = ["b", "d"]
    assert recall_at_k(retrieved, relevant, k=4) == 1.0


def test_recall_at_k_partial_and_cutoff():
    retrieved = ["a", "b", "c", "d"]
    relevant = ["b", "z"]  # "z" was never retrieved at all
    assert recall_at_k(retrieved, relevant, k=4) == 0.5
    # Cutting off before "b" appears should drop recall to 0.
    assert recall_at_k(retrieved, relevant, k=1) == 0.0


def test_recall_at_k_no_relevant_docs_is_zero_not_error():
    assert recall_at_k(["a", "b"], [], k=5) == 0.0


def test_precision_at_k_basic():
    retrieved = ["a", "b", "c", "d"]
    relevant = ["a", "c", "z"]
    # top-4: a (hit), b (miss), c (hit), d (miss) -> 2/4
    assert precision_at_k(retrieved, relevant, k=4) == 0.5


def test_precision_at_k_empty_retrieved_is_zero():
    assert precision_at_k([], ["a"], k=5) == 0.0


def test_reciprocal_rank_first_hit_position():
    assert reciprocal_rank(["x", "y", "a", "b"], ["a"]) == 1 / 3
    assert reciprocal_rank(["a", "y"], ["a"]) == 1.0
    assert reciprocal_rank(["x", "y"], ["a"]) == 0.0


def test_mean_reciprocal_rank_averages_across_queries():
    retrieved_lists = [["a", "b"], ["x", "y", "b"]]
    relevant_lists = [["a"], ["b"]]
    # query 1: rank 1 -> RR=1.0 ; query 2: rank 3 -> RR=1/3
    expected = (1.0 + 1 / 3) / 2
    assert abs(mean_reciprocal_rank(retrieved_lists, relevant_lists) - expected) < 1e-9


def test_ndcg_at_k_perfect_ranking_is_one():
    retrieved = ["a", "b", "c"]
    relevant = ["a", "b"]
    # Perfect ranking (both relevant docs first) should score a perfect 1.0
    assert abs(ndcg_at_k(retrieved, relevant, k=3) - 1.0) < 1e-9


def test_ndcg_at_k_worse_ranking_scores_lower_than_perfect():
    perfect = ndcg_at_k(["a", "b", "c"], ["a", "b"], k=3)
    worse = ndcg_at_k(["c", "a", "b"], ["a", "b"], k=3)
    assert worse < perfect


def test_ndcg_at_k_no_relevant_docs_is_zero():
    assert ndcg_at_k(["a", "b"], [], k=3) == 0.0


def test_dcg_at_k_binary_relevance_matches_hand_calculation():
    # relevant items at positions 1 and 3 (1-indexed):
    # DCG = 1/log2(2) + 1/log2(4) = 1.0 + 0.5 = 1.5
    dcg = dcg_at_k(["a", "x", "b"], ["a", "b"], k=3)
    assert abs(dcg - 1.5) < 1e-9


class _FakeChunk:
    """Minimal stand-in for retrieval.retriever.RetrievedChunk in tests."""

    def __init__(self, chunk_id: str):
        self.chunk_id = chunk_id


def test_evaluate_retrieval_end_to_end_with_fake_retriever():
    golden = [
        {"question": "q1", "relevant_chunk_ids": ["a"]},
        {"question": "q2", "relevant_chunk_ids": ["z"]},  # will never be found
    ]

    def fake_retrieve_fn(question: str, k: int):
        # Always returns the same 3 fake chunks regardless of question.
        return [_FakeChunk("a"), _FakeChunk("b"), _FakeChunk("c")][:k]

    result = evaluate_retrieval(golden, fake_retrieve_fn, k=3)

    assert result.k == 3
    assert len(result.per_query) == 2
    # q1 found its one relevant doc at rank 1 -> recall=1, precision=1/3, rr=1
    assert result.per_query[0]["recall"] == 1.0
    assert result.per_query[0]["reciprocal_rank"] == 1.0
    # q2's relevant doc "z" is never retrieved -> recall=0, rr=0
    assert result.per_query[1]["recall"] == 0.0
    assert result.per_query[1]["reciprocal_rank"] == 0.0
    # Averages should be the mean of the two per-query values.
    assert abs(result.recall_at_k - 0.5) < 1e-9
    assert abs(result.mrr - 0.5) < 1e-9
