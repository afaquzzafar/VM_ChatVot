# 🏥 Healthcare - Retail Product & Fees Assistant

A Retrieval-Augmented Generation (RAG) chatbot that answers questions about
retail health plan products, benefits, and fees **strictly from plan
documents your organization has ingested** — Evidence of Coverage (EOC),
Summary of Benefits and Coverage (SBC), plan manuals, or any other plan
PDF. Every answer is grounded in retrieved document text and cited with a
source filename, page number, and (when detected) section/subsection.

## How it works

| # | Step | Where |
|---|------|-------|
| 1 | Ingest PDF files (**backend-only**, not from the chat UI) | `ingestion/ingest_cli.py` |
| 2 | Extract text from PDFs | `ingestion/pdf_loader.py` |
| 3 | Mask PHI/PII in the extracted text | `ingestion/pii_masking.py` |
| 4 | Section/subsection-aware chunking | `chunking/text_splitter.py` |
| 5 | Generate embeddings | `embeddings/embedding_service.py` |
| 6 | Store embeddings in ChromaDB + rebuild the BM25 keyword index | `vectorstore/chroma_manager.py`, `retrieval/bm25_index.py` |
| 7 | Screen the incoming question for prompt injection | `guardrails/prompt_injection.py` |
| 8 | Expand the question into paraphrases (Multi-Query Retrieval) | `retrieval/multi_query.py` |
| 9 | Hybrid retrieval: BM25 + vector search, fused with RRF | `retrieval/hybrid_retriever.py` |
| 10 | Cross-encoder reranking of the fused candidate pool | `retrieval/reranker.py` |
| 11 | Generate a grounded, cited response | `prompts/prompt_template.py`, `rag/rag_pipeline.py` |
| 12 | Suggest up to 3 follow-up questions | `prompts/followup_prompt.py` |
| 13 | Display the chat, citations, and follow-up chips | `frontend/streamlit_ui.py` |

`orchestration/graph.py` wires steps 7–12 together as a LangGraph
StateGraph; `rag/rag_pipeline.py` is the single entry point both the chat
UI and the ingestion CLI talk to; `app.py` launches the Streamlit UI.

## Tech stack

- **Frontend:** Streamlit — **chat interface only**, no document upload UI
- **Orchestration:** LangGraph (guardrail → retrieve → rerank → generate → suggest follow-ups)
- **Retrieval:** Hybrid (BM25 keyword search + vector search, fused via Reciprocal Rank Fusion), Multi-Query Retrieval, cross-encoder reranking
- **LLM:** Configurable — Databricks Foundation Model APIs or OpenAI GPT-4o (unchanged auth/config from the original project)
- **Embeddings:** OpenAI `text-embedding-3-large` or local `all-MiniLM-L6-v2` (unchanged)
- **Framework:** LangChain + LangGraph
- **Vector DB:** ChromaDB (local, persisted to disk)
- **Keyword index:** `rank_bm25` (local, persisted to disk)
- **PDF parsing:** PyMuPDF
- **PHI/PII masking:** regex-based by default; pluggable Presidio (NER) engine

## Folder structure

```
.
├── app.py                          # Entry point: `streamlit run app.py`
├── requirements.txt
├── .gitignore
│
├── data/
│   ├── pdfs/                        # PDFs to be ingested by the backend CLI
│   ├── chroma_db/                   # Persisted vector database
│   ├── bm25_index.pkl               # Persisted BM25 keyword index
│   └── eval/                        # Golden evaluation dataset + helpers
│
├── ingestion/
│   ├── pdf_loader.py                 # PDF -> plain text (PyMuPDF)
│   ├── pii_masking.py                # PHI/PII masking (regex, pluggable Presidio)
│   └── ingest_cli.py                 # Backend-only ingestion entry point
│
├── chunking/
│   └── text_splitter.py              # Section/subsection-aware chunking
│
├── embeddings/
│   └── embedding_service.py          # text -> vectors (OpenAI or local)
│
├── vectorstore/
│   └── chroma_manager.py             # Store/search vectors (ChromaDB)
│
├── retrieval/
│   ├── bm25_index.py                 # Sparse keyword index (BM25)
│   ├── hybrid_retriever.py           # BM25 + vector, fused via RRF
│   ├── multi_query.py                # LLM-driven query expansion (MQR)
│   ├── reranker.py                   # Cross-encoder reranking
│   └── retriever.py                  # Vector-only retriever (kept for reference/fallback)
│
├── guardrails/
│   └── prompt_injection.py           # Direct + indirect prompt injection guardrail
│
├── orchestration/
│   └── graph.py                      # LangGraph StateGraph for the QA path
│
├── rag/
│   └── rag_pipeline.py               # Orchestrates ingestion + question answering
│
├── prompts/
│   ├── prompt_template.py            # Grounded, citation-enforcing system prompt
│   └── followup_prompt.py            # Suggested follow-up question prompt
│
├── evaluation/
│   ├── metrics.py                    # Recall@K, Precision@K, MRR, NDCG@K
│   ├── run_eval.py                   # CLI to score retrieval against a golden dataset
│   └── build_golden_dataset_template.py
│
├── frontend/
│   └── streamlit_ui.py               # Chat-only UI: no upload/ingest/clear controls
│
├── utils/
│   ├── config.py                      # Centralized settings (reads .env)
│   └── logger.py                      # Shared logging setup
│
└── tests/
    ├── test_chunking.py
    ├── test_prompt_template.py
    └── test_evaluation_metrics.py
```

## Setup

1. **Clone/copy this project**, then create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure your environment:**
   ```bash
   cp .env.example .env
   ```
   Authentication / API key handling is unchanged from the original
   project — set `OPENAI_API_KEY` (and/or Databricks settings) exactly as
   before. New, non-auth settings you can tune in `.env` (all optional,
   sensible defaults are built in): `APP_NAME`, `ENABLE_HYBRID_RETRIEVAL`,
   `ENABLE_MULTI_QUERY`, `MULTI_QUERY_COUNT`, `ENABLE_RERANKER`,
   `RERANKER_MODEL`, `ENABLE_PROMPT_INJECTION_GUARD`, `ENABLE_PII_MASKING`,
   `ENABLE_FOLLOWUP_QUESTIONS`, `MAX_FOLLOWUP_QUESTIONS`.

4. **Ingest your plan documents (backend-only):**
   ```bash
   python -m ingestion.ingest_cli data/pdfs/Plan_EOC_2026.pdf data/pdfs/Plan_SBC_2026.pdf
   # or ingest everything already sitting in data/pdfs/:
   python -m ingestion.ingest_cli --all
   ```
   This runs extraction, PHI/PII masking, section-aware chunking,
   embedding, vector storage, and BM25 index building. There is no upload
   button in the chat UI — this is intentional (see
   `frontend/streamlit_ui.py`'s module docstring).

5. **Run the chat app:**
   ```bash
   streamlit run app.py
   ```
   This opens the app in your browser (usually `http://localhost:8501`).

## Using the app

1. Ask a question in the chat box — e.g. *"What is my annual
   deductible?"* or *"Do I need a referral to see a specialist?"*
2. Each answer includes an expandable **"📚 Sources"** panel showing which
   document, page, and section every fact came from.
3. Up to 3 suggested follow-up questions appear as clickable chips under
   each answer.
4. If no documents have been indexed yet, the assistant says so and points
   to your administrator rather than offering an upload control.

## Evaluating retrieval quality

```bash
# 1. Dump every stored chunk's id, to help you build a labeled dataset:
python -m evaluation.build_golden_dataset_template --out data/eval/chunk_inventory.json

# 2. Hand-write data/eval/golden_dataset.json (question -> relevant chunk_ids)
#    — see data/eval/README.md.

# 3. Score the retrieval pipeline:
python -m evaluation.run_eval --dataset data/eval/golden_dataset.json --k 5

# Compare configurations, e.g. does MQR + reranking actually help?
python -m evaluation.run_eval --no-mqr --no-rerank --report reports/baseline.json
python -m evaluation.run_eval --report reports/full_pipeline.json
```

Reports Recall@K, Precision@K, MRR, and NDCG@K, both averaged and
per-query.

## Running tests

```bash
pip install pytest
pytest tests/ -v
```

`test_chunking.py` and `test_evaluation_metrics.py` run with no external
services at all; `test_prompt_template.py` doesn't call the LLM either —
none of these tests need an API key.

## Key design decisions

- **Grounded-only answers:** The system prompt (`prompts/prompt_template.py`)
  strictly instructs the LLM to answer only from retrieved document
  chunks, and to say "I don't know" (and point the user to Member
  Services) rather than guess.
- **Citations by design:** Every chunk carries `source_file`, `page_number`,
  and `section`/`subsection` metadata from the moment it's extracted all
  the way through to the final answer, so nothing has to be "guessed" or
  reconstructed after the fact.
- **Backend-only ingestion:** Document ingestion is a deliberately separate
  trust boundary from chatting — see `ingestion/ingest_cli.py` and the
  module docstring in `frontend/streamlit_ui.py`.
- **PHI/PII masking at ingestion time:** No raw personal information from
  an uploaded plan document reaches the embedding model, the vector store,
  the BM25 index, or the LLM prompt — see `ingestion/pii_masking.py`.
- **Defense-in-depth against prompt injection:** A fast heuristic guardrail
  screens both the user's live question (direct injection) and retrieved
  document text (indirect injection) — see `guardrails/prompt_injection.py`
  — layered with explicit system-prompt rules that treat retrieved context
  as untrusted data, never instructions.
- **Hybrid retrieval + reranking:** BM25 catches exact terms (dollar
  amounts, defined terms, codes) that dense vector search can blur
  together; Multi-Query Retrieval covers multiple phrasings of the same
  question; a cross-encoder reranks the fused candidate pool for the final
  precision pass. See `retrieval/`.
- **Local-first:** ChromaDB and the BM25 index both persist to local
  folders (`data/chroma_db/`, `data/bm25_index.pkl`), so the whole
  pipeline (except the LLM/embedding API calls themselves) runs with no
  external database service to set up.

## Extending this project

- **New document types:** Add more PDFs to `data/pdfs/` and re-run
  `ingestion/ingest_cli.py` — no code changes needed.
- **Swap the vector DB:** `retrieval/hybrid_retriever.py` and
  `rag/rag_pipeline.py` depend only on `ChromaManager`'s small interface,
  so you could implement an alternative manager and swap it in with
  minimal changes elsewhere.
- **Swap the LLM:** Change `OPENAI_CHAT_MODEL` / `DATABRICKS_CHAT_ENDPOINT`
  in `.env` — the provider selection logic in `rag/rag_pipeline.py` is
  unchanged from the original project.
- **Swap the reranker or PII engine:** `RERANKER_MODEL` in `.env` swaps
  the cross-encoder model; `PII_MASKING_ENGINE=presidio` (plus installing
  the optional Presidio dependencies) swaps in NER-based PHI/PII detection
  — see `ingestion/pii_masking.py`.

## Disclaimer

This assistant summarizes ingested plan documents; it does not provide
legal, medical, or financial advice, and it does not make coverage
decisions. Always confirm important details with Member Services or your
official plan documents.
