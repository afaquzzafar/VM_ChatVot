# ==============================================================================
# ingestion/pii_masking.py
# ------------------------------------------------------------------------------
# NEW MODULE — PHI/PII masking, applied during INGESTION only.
#
# WHERE THIS RUNS IN THE PIPELINE:
#   PDF file --(ingestion/pdf_loader.py)--> plain text + page metadata
#            --(THIS FILE)--> PHI/PII-masked text
#            --(chunking/text_splitter.py)--> chunks
#            --(embeddings + vectorstore)--> stored
#
#   Masking happens BEFORE chunking and BEFORE anything is embedded, so no
#   raw PHI/PII ever reaches the embedding model, the vector store, the BM25
#   keyword index, or (via retrieval) the LLM prompt. This matters for a
#   healthcare/insurance assistant: uploaded plan documents can carry a real
#   member's name, date of birth, SSN, member ID, phone number, etc. even
#   though the assistant's job is to answer questions about PLAN DESIGN
#   (deductibles, copays, covered services), not about any individual.
#
# WHAT THIS FILE DOES NOT DO:
#   It does not mask the user's live chat QUESTION — only ingested document
#   text. Masking a live question would risk corrupting the user's own
#   query (e.g. if they paste part of their own EOB to ask about it), and
#   the ask() path already never writes chat questions into the knowledge
#   base, so there is nothing to protect there.
#
# WHY REGEX FIRST, NOT A HEAVY NER MODEL:
#   Enterprise-grade PHI detection (Microsoft Presidio, AWS Comprehend
#   Medical, etc.) uses NLP/NER models and is the recommended upgrade path
#   for production — see `PresidioPIIMasker` stub below for the swap point.
#   Insurance plan documents (EOC/SBC/Manuals) are template-driven, so a
#   well-tuned regex/keyword engine catches the overwhelming majority of
#   PHI/PII patterns (SSNs, member IDs, MBIs, DOBs, phone, email, etc.)
#   with zero extra model downloads, no GPU, and no added ingestion latency
#   — a good default for a self-contained deployment.
# ==============================================================================

import re
from dataclasses import dataclass, field, replace
from typing import List, Tuple

from ingestion.pdf_loader import PageContent
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


@dataclass
class MaskingReport:
    """Summary of what was redacted from one document, for audit logging."""

    counts_by_type: dict = field(default_factory=dict)

    @property
    def total(self) -> int:
        return sum(self.counts_by_type.values())

    def merge(self, other: "MaskingReport") -> None:
        for k, v in other.counts_by_type.items():
            self.counts_by_type[k] = self.counts_by_type.get(k, 0) + v


# ------------------------------------------------------------------------------
# Pattern-based entity detectors.
#
# Each entry: (label, compiled regex, replacement token).
# Order matters — more specific patterns (SSN, MBI, credit card) run before
# generic ones (bare numbers) so they aren't partially double-masked.
# ------------------------------------------------------------------------------
_PATTERNS: List[Tuple[str, re.Pattern, str]] = [
    # Social Security Number: 123-45-6789 or 123 45 6789
    ("SSN", re.compile(r"\b\d{3}[-\s]\d{2}[-\s]\d{4}\b"), "[REDACTED_SSN]"),
    # Medicare Beneficiary Identifier (MBI): 11 chars, e.g. 1EG4-TE5-MK73
    ("MBI", re.compile(r"\b[1-9][A-Z0-9]{3}-[A-Z0-9]{3}-[A-Z0-9]{4}\b"), "[REDACTED_MBI]"),
    # Credit / debit card numbers (13-19 digits, optionally grouped)
    (
        "CARD_NUMBER",
        re.compile(r"\b(?:\d[ -]?){13,19}\b"),
        "[REDACTED_CARD_NUMBER]",
    ),
    # Email addresses
    (
        "EMAIL",
        re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
        "[REDACTED_EMAIL]",
    ),
    # US phone numbers: (555) 123-4567, 555-123-4567, 555.123.4567, +1 555 123 4567
    # (no leading \b: a phone number is routinely preceded by "(", which is
    # a non-word character, so anchoring on \b there would skip the "("
    # and leave it dangling in the output instead of being masked with it)
    (
        "PHONE",
        re.compile(
            r"(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b"
        ),
        "[REDACTED_PHONE]",
    ),
    # Full dates (birthdates, admission dates, etc.): 01/02/2026, 1-2-2026, Jan 2, 2026
    (
        "DATE",
        re.compile(
            r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}"
            r"|(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|"
            r"Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|"
            r"Dec(?:ember)?)\s+\d{1,2},?\s+\d{4})\b"
        ),
        "[REDACTED_DATE]",
    ),
]

# ------------------------------------------------------------------------------
# Keyword-anchored masking: "<Label>: <value up to end of line>" — used for
# fields that aren't structurally unique enough to regex-match safely on
# their own (a bare name or a bare ID number looks like ordinary text), but
# ARE safe to mask once we know the label that precedes them.
# ------------------------------------------------------------------------------
_LABELED_FIELD_LABELS = [
    "member name", "patient name", "subscriber name", "insured name",
    "beneficiary name", "employee name", "dependent name",
    "member id", "subscriber id", "policy number", "policy id",
    "group number", "account number", "medical record number", "mrn",
    "date of birth", "dob", "social security number", "ssn",
    "address", "mailing address", "home address",
    "phone", "phone number", "fax", "fax number",
]
_LABEL_PATTERN = re.compile(
    r"(?im)^(?P<label>\s*(?:" + "|".join(re.escape(l) for l in _LABELED_FIELD_LABELS)
    + r")\s*:?\s*)(?P<value>.+)$"
)


class RegexPIIMasker:
    """
    Default PHI/PII masking engine: layered regex + keyword-anchored rules.
    No external services, no model downloads — safe to run in any
    environment, including fully offline / air-gapped deployments.
    """

    def mask_text(self, text: str) -> Tuple[str, MaskingReport]:
        report = MaskingReport()
        masked = text

        # 1. Keyword-anchored fields (Name:, DOB:, Member ID:, Address:, ...)
        def _replace_labeled(match: "re.Match") -> str:
            report.counts_by_type["LABELED_FIELD"] = (
                report.counts_by_type.get("LABELED_FIELD", 0) + 1
            )
            return f"{match.group('label')}[REDACTED]"

        masked = _LABEL_PATTERN.sub(_replace_labeled, masked)

        # 2. Structural patterns (SSN, MBI, card, email, phone, date)
        for label, pattern, token in _PATTERNS:
            masked, n = pattern.subn(token, masked)
            if n:
                report.counts_by_type[label] = report.counts_by_type.get(label, 0) + n

        return masked, report


# ------------------------------------------------------------------------------
# Swap-in point for a production-grade NER-based engine. Kept as a thin,
# optional wrapper so ops can switch engines via config without touching any
# calling code — mask_pages() below only depends on the .mask_text() method.
# ------------------------------------------------------------------------------
class PresidioPIIMasker:
    """
    Optional upgrade path: wraps Microsoft Presidio's Analyzer + Anonymizer
    for NER-based PHI/PII detection (catches free-text names, addresses,
    and locations that plain regex can miss). Not installed by default —
    requires `presidio-analyzer`, `presidio-anonymizer`, and a spaCy model.
    Falls back to RegexPIIMasker automatically if Presidio isn't available.
    """

    def __init__(self):
        from presidio_analyzer import AnalyzerEngine  # type: ignore
        from presidio_anonymizer import AnonymizerEngine  # type: ignore

        self._analyzer = AnalyzerEngine()
        self._anonymizer = AnonymizerEngine()

    def mask_text(self, text: str) -> Tuple[str, MaskingReport]:
        results = self._analyzer.analyze(text=text, language="en")
        anonymized = self._anonymizer.anonymize(text=text, analyzer_results=results)
        report = MaskingReport()
        for r in results:
            report.counts_by_type[r.entity_type] = report.counts_by_type.get(r.entity_type, 0) + 1
        return anonymized.text, report


def get_pii_masker():
    """
    Factory used by the ingestion pipeline. Tries the configured engine and
    always has a safe fallback to the dependency-free regex masker, so
    ingestion never hard-fails because an optional NLP dependency is missing.
    """
    engine = "regex"
    try:
        import os

        engine = os.getenv("PII_MASKING_ENGINE", "regex").lower()
        if engine == "presidio":
            return PresidioPIIMasker()
    except Exception as exc:  # pragma: no cover - optional dependency path
        logger.warning(
            f"Presidio PII engine unavailable ({exc}); falling back to regex-based masking"
        )
    return RegexPIIMasker()


def mask_pages(pages: List[PageContent]) -> List[PageContent]:
    """
    Run PHI/PII masking over every page's extracted text BEFORE chunking.

    Args:
        pages: PageContent objects straight from ingestion/pdf_loader.py

    Returns:
        A new list of PageContent objects with masked text. Metadata
        (source_file, page_number) is preserved untouched so citations
        still point at the correct document/page even though the text
        content itself has been redacted.
    """
    if not settings.enable_pii_masking:
        logger.info("PII masking is disabled (ENABLE_PII_MASKING=false) — skipping")
        return pages

    masker = get_pii_masker()
    masked_pages: List[PageContent] = []
    total_report = MaskingReport()

    for page in pages:
        masked_text, page_report = masker.mask_text(page.text)
        total_report.merge(page_report)
        masked_pages.append(replace(page, text=masked_text))

    if total_report.total:
        logger.info(
            f"PII masking redacted {total_report.total} item(s) across "
            f"{len(pages)} page(s): {total_report.counts_by_type}"
        )
    else:
        logger.info(f"PII masking found nothing to redact across {len(pages)} page(s)")

    return masked_pages
