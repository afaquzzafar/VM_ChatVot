# ==============================================================================
# ingestion/ingest_cli.py
# ------------------------------------------------------------------------------
# NEW MODULE — Backend-only document ingestion entry point.
#
# WHY THIS EXISTS:
#   The Streamlit UI (frontend/streamlit_ui.py) no longer has an upload
#   widget or an "Ingest Documents" button — ingestion is now a BACKEND
#   operation, run by an operator/administrator via this script (or
#   whatever scheduled job / admin tool wraps it), never by an end user
#   typing in the chat window. This separates two very different trust
#   levels: anyone who can chat with the assistant should NOT also be able
#   to add or replace the documents it's grounded in, and it keeps PHI/PII
#   masking (ingestion/pii_masking.py) as a mandatory, un-skippable step
#   that every document goes through on the way in — there's no "upload
#   and immediately chat" path that could bypass it.
#
# USAGE:
#     # Ingest specific files:
#     python -m ingestion.ingest_cli data/pdfs/Plan_EOC_2026.pdf data/pdfs/Plan_SBC_2026.pdf
#
#     # Ingest every PDF already sitting in the configured upload folder:
#     python -m ingestion.ingest_cli --all
#
#     # Wipe the knowledge base (vector store + BM25 index) and start over:
#     python -m ingestion.ingest_cli --clear --all
# ==============================================================================

import argparse
import glob
import os
import sys

from rag.rag_pipeline import RAGPipeline
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


def _discover_pdfs_in_upload_dir() -> list:
    pattern = os.path.join(settings.pdf_upload_dir, "*.pdf")
    return sorted(glob.glob(pattern))


def main() -> None:
    parser = argparse.ArgumentParser(
        description=f"Backend-only document ingestion for the {settings.app_name}. "
        "Not exposed in the chat UI on purpose — see frontend/streamlit_ui.py."
    )
    parser.add_argument(
        "files",
        nargs="*",
        help="PDF file path(s) to ingest. Omit and pass --all to ingest every PDF "
        "already in the configured upload folder instead.",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help=f"Ingest every *.pdf file currently in '{settings.pdf_upload_dir}'",
    )
    parser.add_argument(
        "--clear",
        action="store_true",
        help="Clear the existing knowledge base (vector store + BM25 index) before ingesting.",
    )
    args = parser.parse_args()

    file_paths = list(args.files)
    if args.all:
        file_paths.extend(_discover_pdfs_in_upload_dir())
    file_paths = sorted(set(file_paths))

    missing = [p for p in file_paths if not os.path.exists(p)]
    if missing:
        logger.error(f"File(s) not found: {missing}")
        sys.exit(1)

    if not file_paths and not args.clear:
        logger.error(
            "No files to ingest. Pass one or more PDF paths, or --all to ingest everything "
            f"in '{settings.pdf_upload_dir}'."
        )
        sys.exit(1)

    pipeline = RAGPipeline()

    if args.clear:
        logger.info("Clearing existing knowledge base before ingesting...")
        pipeline.chroma_manager.clear_collection()
        pipeline.hybrid_retriever.refresh_bm25_index()

    if file_paths:
        logger.info(f"Ingesting {len(file_paths)} file(s): {file_paths}")
        chunk_count = pipeline.ingest_documents(file_paths)
        print(f"\nIngestion complete: {chunk_count} chunk(s) stored from {len(file_paths)} file(s).")
        print(f"Total chunks now in knowledge base: {pipeline.chroma_manager.document_count()}")
    else:
        print("Knowledge base cleared. No new files were ingested.")


if __name__ == "__main__":
    main()
