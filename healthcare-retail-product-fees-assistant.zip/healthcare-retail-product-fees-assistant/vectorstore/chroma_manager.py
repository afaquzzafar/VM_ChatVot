# ==============================================================================
# vectorstore/chroma_manager.py
# ------------------------------------------------------------------------------
# STEP 5 of the RAG pipeline: "Store embeddings in vector database"
#
# WHAT IS A VECTOR DATABASE? (GenAI beginners)
#   A normal database is great at exact lookups ("find the row where
#   id = 42"). A VECTOR database is built for a different kind of lookup:
#   "find the vectors that are mathematically closest to THIS vector."
#   That "closeness" search is called a SIMILARITY SEARCH, and it's the
#   engine behind RAG retrieval — see retrieval/retriever.py for Step 6.
#
# WHY ChromaDB SPECIFICALLY:
#   ChromaDB is open-source, runs entirely locally (no external service or
#   account needed), and persists its data to a folder on disk
#   (data/chroma_db/ in this project), which is perfect for a local-machine
#   VS Code prototype like this one. It also integrates directly with
#   LangChain, so we don't have to hand-write vector math ourselves.
#
# WHAT GETS STORED PER CHUNK:
#   For every text chunk we store THREE things together:
#     1. the embedding vector (for similarity search)
#     2. the original chunk text (so we can show/send it to the LLM later)
#     3. metadata: source filename + page number (so we can cite it later)
#
# HOW THIS FITS INTO THE BIGGER PICTURE:
#   chunks + vectors --(this file)--> persisted to disk in data/chroma_db/
#   Later, at question-answering time, retrieval/retriever.py re-opens this
#   same persisted database and searches it.
# ==============================================================================

import os
from typing import List, Optional

from langchain_chroma import Chroma
from langchain_core.documents import Document

from chunking.text_splitter import Chunk
from embeddings.embedding_service import EmbeddingService
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class ChromaManager:
    """
    Manages a single persistent ChromaDB collection: creating it, adding
    document chunks to it, and exposing it for similarity search.
    """

    def __init__(self, embedding_service: Optional[EmbeddingService] = None):
        # Reuse a shared EmbeddingService if one is passed in (e.g., by the
        # RAG pipeline that also needs it for embedding the user's
        # question) — otherwise create a fresh one.
        self.embedding_service = embedding_service or EmbeddingService()

        # Make sure the folder Chroma will write its on-disk database files
        # into actually exists before we try to use it.
        os.makedirs(settings.chroma_persist_dir, exist_ok=True)

        # LangChain's Chroma wrapper handles:
        #   - opening (or creating) the on-disk database at persist_directory
        #   - calling our embedding model whenever .add_documents() or
        #     .similarity_search() is used
        self.vectorstore = Chroma(
            collection_name=settings.chroma_collection_name,
            embedding_function=self.embedding_service.get_langchain_embeddings(),
            persist_directory=settings.chroma_persist_dir,
        )

        logger.info(
            f"ChromaManager ready. Collection='{settings.chroma_collection_name}', "
            f"persist_dir='{settings.chroma_persist_dir}'"
        )

    def add_chunks(self, chunks: List[Chunk]) -> int:
        """
        Embed and store a batch of text chunks in ChromaDB.

        Args:
            chunks: list of Chunk objects from chunking/text_splitter.py

        Returns:
            The number of chunks successfully added.
        """
        if not chunks:
            logger.warning("add_chunks() called with an empty chunk list — nothing to do")
            return 0

        # LangChain's Chroma store expects LangChain "Document" objects:
        # page_content (the text) + metadata (a dict). Internally, when we
        # call add_documents(), Chroma will:
        #   1. call self.embedding_service to turn each chunk's text into a
        #      vector (this is Step 4 happening again, but batched)
        #   2. write {vector, text, metadata, id} into the on-disk database
        documents = [
            Document(page_content=chunk.text, metadata=chunk.metadata)
            for chunk in chunks
        ]
        ids = [chunk.chunk_id for chunk in chunks]

        logger.info(f"Embedding and storing {len(documents)} chunks in ChromaDB...")
        self.vectorstore.add_documents(documents=documents, ids=ids)
        logger.info("Chunks stored successfully (persisted to disk automatically)")

        return len(documents)

    def get_retriever(self, top_k: int = None):
        """
        Return a LangChain "retriever" object configured for similarity
        search. A retriever is just a standardized interface LangChain uses
        so that different vector stores (Chroma, Pinecone, FAISS, etc.) can
        all be swapped in and out of a RAG chain without changing other code.

        Args:
            top_k: how many of the most similar chunks to return per query.
                   Defaults to settings.retrieval_top_k from utils/config.py.
        """
        k = top_k or settings.retrieval_top_k
        return self.vectorstore.as_retriever(search_kwargs={"k": k})

    def similarity_search_with_scores(self, query: str, top_k: int = None):
        """
        Directly run a similarity search and return chunks WITH their
        similarity scores. Useful when we want to show the user "how
        confident" the retrieval was, or filter out weak matches.

        Args:
            query: the (already-plain-text) user question
            top_k: number of chunks to retrieve

        Returns:
            List of (Document, score) tuples. For Chroma, a LOWER score
            means MORE similar (it's a distance metric, not a percentage).
        """
        k = top_k or settings.retrieval_top_k
        return self.vectorstore.similarity_search_with_score(query, k=k)

    def similarity_search_with_scores_and_ids(self, query: str, top_k: int = None) -> List[tuple]:
        """
        Like similarity_search_with_scores(), but also returns each result's
        stable chunk id (the same id assigned as `Chunk.chunk_id` at
        chunking time and used as the Chroma document id when it was
        stored). retrieval/hybrid_retriever.py needs this shared id to fuse
        vector-search results with BM25 keyword-search results on the same
        identifier via Reciprocal Rank Fusion.

        Args:
            query: the (already-plain-text) user question
            top_k: number of chunks to retrieve

        Returns:
            List of (chunk_id, Document, distance) tuples, ordered by
            increasing distance (most similar first).
        """
        k = top_k or settings.retrieval_top_k
        query_embedding = self.embedding_service.embed_query(query)

        raw = self.vectorstore._collection.query(
            query_embeddings=[query_embedding],
            n_results=k,
            include=["documents", "metadatas", "distances"],
        )
        ids = (raw.get("ids") or [[]])[0]
        texts = (raw.get("documents") or [[]])[0]
        metadatas = (raw.get("metadatas") or [[]])[0]
        distances = (raw.get("distances") or [[]])[0]

        return [
            (chunk_id, Document(page_content=text or "", metadata=metadata or {}), float(distance))
            for chunk_id, text, metadata, distance in zip(ids, texts, metadatas, distances)
        ]

    def document_count(self) -> int:
        """Return how many chunks are currently stored in the collection."""
        return self.vectorstore._collection.count()

    def get_all_documents(self) -> List[tuple]:
        """
        Fetch every chunk currently stored in the collection as
        (chunk_id, Document) pairs, including their text and metadata.

        Vector similarity search only ever returns the top-K nearest
        neighbors of one query, so it can't be used to build a full-corpus
        keyword index. This method exists specifically so
        retrieval/bm25_index.py can build/rebuild a BM25 index from the
        SAME chunks that are already stored in Chroma, without keeping a
        second copy of the corpus in memory or on disk.

        Returns:
            A list of (chunk_id, Document) tuples. Empty list if the
            collection has nothing indexed yet.
        """
        if self.document_count() == 0:
            return []

        raw = self.vectorstore._collection.get(include=["documents", "metadatas"])
        ids = raw.get("ids", [])
        texts = raw.get("documents", [])
        metadatas = raw.get("metadatas", [])

        return [
            (doc_id, Document(page_content=text or "", metadata=metadata or {}))
            for doc_id, text, metadata in zip(ids, texts, metadatas)
        ]

    def clear_collection(self) -> None:
        """
        Delete ALL vectors in the current collection. Useful when a user
        wants to re-upload documents from scratch rather than accumulating
        duplicates across sessions.
        """
        logger.warning(f"Clearing all vectors from collection '{settings.chroma_collection_name}'")
        existing_ids = self.vectorstore._collection.get()["ids"]
        if existing_ids:
            self.vectorstore._collection.delete(ids=existing_ids)
        logger.info("Collection cleared")
