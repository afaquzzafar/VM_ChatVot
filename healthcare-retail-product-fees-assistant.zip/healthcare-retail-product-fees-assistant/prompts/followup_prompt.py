# ==============================================================================
# prompts/followup_prompt.py
# ------------------------------------------------------------------------------
# NEW MODULE — Suggested follow-up questions (max 3).
#
# WHY THIS EXISTS:
#   After answering a question, users often don't know what else the
#   assistant can help with, or what the NATURAL next question is (e.g.
#   after asking about the deductible, "what about out-of-network
#   deductible?" or "how does this apply to prescription drugs?"). A short
#   list of suggested follow-ups makes the chat interface feel guided
#   rather than a blank box the user has to keep re-priming.
#
# WHY A SEPARATE LLM CALL (not folded into the main answer):
#   Keeping this as its own small, focused prompt means:
#     - the main grounded answer stays exactly as strict/citation-heavy as
#       prompts/prompt_template.py defines, with zero risk of the
#       follow-up suggestions leaking into or diluting that answer text
#     - follow-up generation can fail or be disabled (see
#       ENABLE_FOLLOWUP_QUESTIONS in utils/config.py) without touching the
#       answer path at all — see orchestration/graph.py's followup_node,
#       which always degrades to an empty list rather than failing the
#       whole response.
# ==============================================================================

from typing import List

FOLLOWUP_PROMPT_TEMPLATE = """Based on the question and answer below, suggest up to {max_questions} \
natural follow-up questions the user might want to ask next about their health plan's benefits, \
coverage, or fees.

Rules:
- Only suggest questions that could plausibly be answered from the same kind of plan documents \
(Evidence of Coverage, Summary of Benefits and Coverage, plan manuals) — benefits, coverage, \
copays, coinsurance, deductibles, claims, appeals, referrals, prior authorization, provider \
networks, fees, or costs.
- Do not repeat the original question or restate the answer.
- Keep each suggestion short (under 15 words) and phrased as a question ending in "?".
- Return ONLY the questions, one per line — no numbering, no bullets, no extra commentary.
- If you can't think of any sensible follow-up questions, return nothing at all.

QUESTION: {question}

ANSWER: {answer}
"""


def build_followup_prompt(question: str, answer: str, max_questions: int) -> str:
    """Build the prompt sent to the LLM to generate suggested follow-up questions."""
    return FOLLOWUP_PROMPT_TEMPLATE.format(
        question=question, answer=answer, max_questions=max_questions
    )


def parse_followup_questions(raw_text: str, max_questions: int) -> List[str]:
    """
    Parse the LLM's raw follow-up-question response into a clean list,
    capped at max_questions. Deliberately lenient about formatting (models
    don't always perfectly follow "no numbering, no bullets"), but strict
    about not returning more than were asked for.
    """
    lines = [line.strip(" \t-*•") for line in (raw_text or "").strip().split("\n")]
    lines = [line for line in lines if line]

    questions = [line for line in lines if line.endswith("?")]
    if not questions:
        # Be lenient: some models drop the trailing "?" — keep any
        # non-trivial line rather than discarding everything.
        questions = [line for line in lines if len(line) > 8]

    return questions[:max_questions]
