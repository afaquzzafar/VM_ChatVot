# ==============================================================================
# frontend/streamlit_ui.py
# ------------------------------------------------------------------------------
# CHAT-ONLY frontend. Document ingestion is now a BACKEND-ONLY operation
# (see ingestion/ingest_cli.py) — this file intentionally has NO upload
# widget, NO "Ingest Documents" button, and NO "Clear knowledge base"
# button. Anyone chatting with the assistant should never also be able to
# add, replace, or wipe the documents it's grounded in; that's an
# administrator action run from the backend, outside the chat surface.
#
# WHAT THIS FILE DOES:
#   Renders the chat window: the user asks a question, sees a grounded
#   answer with source citations, and up to a few suggested follow-up
#   questions they can click instead of retyping. A small read-only status
#   line shows whether a knowledge base is currently loaded, since a
#   chat-only UI still needs to explain a "no documents yet" situation
#   without offering a way to fix it from here.
#
# HOW STREAMLIT WORKS (GenAI / web beginners):
#   Streamlit re-runs this ENTIRE script from top to bottom every time the
#   user interacts with a widget (clicks a button, types a message, etc.).
#   That means any data we want to "remember" between interactions — like
#   chat history, or whether the RAG pipeline has already been initialized —
#   must be stored in `st.session_state`, a dictionary-like object Streamlit
#   preserves across re-runs for a given browser session.
# ==============================================================================

import os
import sys

import streamlit as st

# Allow "import rag.rag_pipeline" etc. to work when this file is run
# directly via `streamlit run frontend/streamlit_ui.py` from the project
# root, by adding the project root to Python's module search path.
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from rag.rag_pipeline import RAGPipeline, RAGResponse  # noqa: E402
from utils.config import settings  # noqa: E402
from utils.logger import get_logger  # noqa: E402

logger = get_logger(__name__)

APP_ICON = "🏥"


def _init_session_state() -> None:
    """
    Set up st.session_state defaults exactly once per browser session.
    Streamlit re-runs this whole script on every interaction, so we must
    guard each key with an "if ... not in st.session_state" check —
    otherwise things like chat history would reset on every message.
    """
    if "rag_pipeline" not in st.session_state:
        # Building the RAGPipeline connects to the chat/embedding
        # providers and opens ChromaDB, so we only want to do this ONCE
        # per session, not on every re-run.
        with st.spinner(f"Starting up the {settings.app_name}..."):
            st.session_state.rag_pipeline: RAGPipeline = RAGPipeline()

    if "chat_history" not in st.session_state:
        # Each entry: {"role": "user"|"assistant", "content": str,
        #              "sources": [...], "followup_questions": [...]}
        st.session_state.chat_history = []

    if "pending_question" not in st.session_state:
        st.session_state.pending_question = None


def _render_sidebar() -> None:
    """
    Read-only status panel: app branding, knowledge-base status, and model
    configuration. No document management controls live here — see the
    module docstring above for why.
    """
    with st.sidebar:
        st.header(f"{APP_ICON} {settings.app_name}")
        st.caption(
            "Ask questions about your retail health plan's benefits, coverage, and fees. "
            "Documents are managed by your administrator, not from this chat window."
        )

        st.divider()

        doc_count = st.session_state.rag_pipeline.chroma_manager.document_count()
        if doc_count > 0:
            st.success(f"✅ Knowledge base ready — {doc_count} chunks indexed")
        else:
            st.warning("⚠️ No documents indexed yet. Please contact your administrator.")

        st.divider()
        st.caption(
            f"**Chat model:** {settings.chat_model}  \n"
            f"**Embedding model:** {settings.embedding_model}  \n"
            f"**Top-K retrieval:** {settings.retrieval_top_k}  \n"
            f"**Hybrid retrieval:** {'on' if settings.enable_hybrid_retrieval else 'off'}  \n"
            f"**Multi-query retrieval:** {'on' if settings.enable_multi_query else 'off'}  \n"
            f"**Reranking:** {'on' if settings.enable_reranker else 'off'}"
        )

        st.divider()
        st.caption(
            "This assistant summarizes uploaded plan documents; it does not provide legal, "
            "medical, or financial advice, and it does not make coverage decisions. Always "
            "confirm important details with Member Services or your official plan documents."
        )


def _render_citations(sources) -> None:
    """
    Renders an expandable "Sources" panel underneath an assistant's answer,
    listing exactly which document + page (and section, when known) each
    retrieved chunk came from, plus a preview of the chunk text itself —
    so the user can verify the chatbot's answer against the original
    document.
    """
    with st.expander(f"📚 Sources ({len(sources)})"):
        for i, chunk in enumerate(sources, start=1):
            location = f"{chunk.source_file} — page {chunk.page_number}"
            if getattr(chunk, "section", None):
                location += f" — {chunk.section}"
            st.markdown(f"**{i}. {location}**")
            preview = chunk.text[:400] + ("..." if len(chunk.text) > 400 else "")
            st.caption(preview)


def _render_followup_questions(questions, message_index: int) -> None:
    """
    Renders up to settings.max_followup_questions suggested follow-up
    questions as clickable buttons. Clicking one queues it as the next
    question to ask, exactly as if the user had typed and submitted it.
    """
    if not questions:
        return
    st.caption("You might also want to ask:")
    cols = st.columns(len(questions))
    for i, (col, question) in enumerate(zip(cols, questions)):
        with col:
            if st.button(question, key=f"followup_{message_index}_{i}", use_container_width=True):
                st.session_state.pending_question = question
                st.rerun()


def _render_chat_history() -> None:
    """
    Redraw every past message in the conversation (Streamlit re-runs the
    script on every interaction, so without this the chat would appear to
    "forget" everything after each new message).
    """
    for i, message in enumerate(st.session_state.chat_history):
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message["role"] == "assistant":
                if message.get("sources"):
                    _render_citations(message["sources"])
                if message.get("followup_questions"):
                    _render_followup_questions(message["followup_questions"], message_index=i)


def _handle_question(question: str) -> None:
    """
    Shared handler for a new question, however it arrived — typed into the
    chat input, or clicked from a suggested follow-up button.
    """
    st.session_state.chat_history.append({"role": "user", "content": question})
    with st.chat_message("user"):
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("Searching your plan documents and drafting an answer..."):
            try:
                response: RAGResponse = st.session_state.rag_pipeline.ask(question)
            except Exception as exc:
                logger.exception("RAG pipeline failed to answer")
                response = RAGResponse(
                    answer=f"⚠️ Sorry, something went wrong while generating an answer: {exc}",
                    sources=[],
                    followup_questions=[],
                )

        st.markdown(response.answer)
        if response.sources:
            _render_citations(response.sources)
        if response.followup_questions:
            _render_followup_questions(
                response.followup_questions, message_index=len(st.session_state.chat_history)
            )

    st.session_state.chat_history.append(
        {
            "role": "assistant",
            "content": response.answer,
            "sources": response.sources,
            "followup_questions": response.followup_questions,
        }
    )


def _render_chat_input() -> None:
    """
    The main chat input box at the bottom of the page, plus handling for a
    question queued by a clicked follow-up suggestion (see
    _render_followup_questions above).
    """
    pending = st.session_state.pending_question
    if pending:
        st.session_state.pending_question = None
        _handle_question(pending)
        return

    question = st.chat_input("Ask a question about your plan's benefits, coverage, or fees...")
    if question:
        _handle_question(question)


def run_app() -> None:
    """Main entry point for the Streamlit application."""
    st.set_page_config(
        page_title=settings.app_name,
        page_icon=APP_ICON,
        layout="wide",
    )

    st.title(f"{APP_ICON} {settings.app_name}")
    st.caption(
        "Ask questions about your plan's benefits, coverage, copays, deductibles, fees, "
        "claims, appeals, and more — answered strictly from your organization's plan documents."
    )

    _init_session_state()
    _render_sidebar()

    if st.session_state.rag_pipeline.chroma_manager.document_count() == 0:
        st.info(
            "👋 Welcome! No plan documents are indexed yet. Please contact your administrator "
            "to load documents, then come back and ask away."
        )

    _render_chat_history()
    _render_chat_input()


# When this module is the Streamlit entry point (e.g. `streamlit run
# frontend/streamlit_ui.py`), call run_app() automatically.  When imported
# from app.py, the caller invokes run_app() explicitly so that Streamlit
# re-runs work correctly (Python caches imports, so a module-level call
# would only fire once).
if __name__ == "__main__":
    run_app()
