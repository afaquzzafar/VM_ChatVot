# Building a golden evaluation dataset

`evaluation/run_eval.py` measures retrieval quality (Recall@K, Precision@K,
MRR, NDCG@K) against a small hand-labeled dataset of
`question -> relevant_chunk_ids`. This folder holds that dataset.

## Steps

1. **Ingest your real documents first** (backend-only — see
   `ingestion/ingest_cli.py`):
   ```bash
   python -m ingestion.ingest_cli data/pdfs/*.pdf
   ```

2. **Dump an inventory of every stored chunk** so you can find real
   `chunk_id` values instead of guessing them:
   ```bash
   python -m evaluation.build_golden_dataset_template --out data/eval/chunk_inventory.json
   ```
   This writes one entry per chunk: `chunk_id`, `source`, `page`,
   `section`/`subsection`, and a short `text_preview`.

3. **Write 15-30 realistic questions** a member/user would actually ask,
   and for each one, find the chunk_id(s) in `chunk_inventory.json` that
   genuinely answer it. Put them in `data/eval/golden_dataset.json`:
   ```json
   [
     {
       "question": "What is the annual individual deductible?",
       "relevant_chunk_ids": ["Plan_EOC_2026.pdf_p14_s2_c0"]
     }
   ]
   ```
   A question can have more than one relevant chunk_id if the answer spans
   multiple chunks (e.g. one chunk for the in-network amount, another for
   out-of-network).

4. **Run the evaluation:**
   ```bash
   python -m evaluation.run_eval --dataset data/eval/golden_dataset.json --k 5
   ```

5. **Compare configurations** to see what each new retrieval component is
   actually contributing:
   ```bash
   # Vector + BM25 only, no Multi-Query, no reranking
   python -m evaluation.run_eval --no-mqr --no-rerank --report reports/baseline.json

   # Full pipeline (hybrid + MQR + cross-encoder rerank)
   python -m evaluation.run_eval --report reports/full_pipeline.json
   ```

The `golden_dataset.json` checked into this repo is a placeholder template
— replace its `REPLACE_WITH_REAL_CHUNK_ID_FROM_chunk_inventory.json`
entries with real ids for whatever plan documents you actually ingest.
