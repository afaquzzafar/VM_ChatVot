# ==============================================================================
# retrieval/multi_query.py
# ------------------------------------------------------------------------------
# NEW MODULE — Multi-Query Retrieval (MQR).
#
# WHAT IS MULTI-QUERY RETRIEVAL? (GenAI beginners)
#   A single retrieval pass is entirely at the mercy of how the user
#   happened to phrase their question. "What's my deductible?" and "How
#   much do I have to pay out of pocket before my plan starts covering
#   costs?" mean almost the same thing to a human, but a single embedding
#   or BM25 pass over just ONE of those phrasings can miss a passage that
#   would have matched the other nearly perfectly.
#
#   MQR asks the LLM to generate several alternative phrasings of the same
#   question, runs Hybrid Retrieval (BM25 + vector) for EACH phrasing, and
#   merges the results — meaningfully increasing recall, especially for
#   plain-language questions about jargon-heavy insurance documents.
#
# HOW THIS FITS INTO THE PIPELINE:
#   question -> [this module: N phrasings] -> HybridRetriever.retrieve()
#   per phrasing -> merged/deduplicated candidate pool
#   -> retrieval/reranker.py (cross-encoder) -> final top-K -> LLM prompt
# ==============================================================================

from typing import List, Tuple

from retrieval.hybrid_retriever import HybridRetriever
from retrieval.retriever import RetrievedChunk
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)

_QUERY_GENERATION_PROMPT = """You help a retrieval system search a set of health insurance plan \
documents (Evidence of Coverage, Summary of Benefits and Coverage, plan manuals).

Given the user's question below, write {n} alternative versions of it that:
- preserve the original meaning and intent EXACTLY — never add new facts, assumptions, or details
- use different phrasing, synonyms, or level of detail, so both a keyword search and a semantic \
search engine each have the best chance of matching the right passage
- are each a single, self-contained question

Return ONLY the {n} alternative questions, one per line. No numbering, no bullets, no commentary.

Original question: {question}"""


class MultiQueryRetriever:
    """
    Wraps a HybridRetriever with LLM-driven query expansion. If no LLM is
    configured, or query generation fails for any reason, this degrades
    gracefully to a single retrieval pass on the original question — MQR is
    a recall booster, never a hard dependency for answering at all.
    """

    def __init__(self, hybrid_retriever: HybridRetriever, llm=None, n_queries: int = None):
        self.hybrid_retriever = hybrid_retriever
        self.llm = llm
        self.n_queries = n_queries or settings.multi_query_count

    def _generate_query_variants(self, question: str) -> List[str]:
        if self.llm is None:
            return []
        try:
            from langchain_core.messages import HumanMessage

            prompt = _QUERY_GENERATION_PROMPT.format(n=self.n_queries, question=question)
            response = self.llm.invoke([HumanMessage(content=prompt)])
            raw_lines = str(response.content).strip().split("\n")
            variants = []
            for line in raw_lines:
                cleaned = line.strip(" \t-*•").strip()
                # Strip a leading "1. " / "1) " style numbering if the model
                # added it despite being asked not to.
                cleaned = cleaned.split(". ", 1)[-1] if cleaned[:2].rstrip(".").isdigit() else cleaned
                if cleaned and cleaned.lower() != question.strip().lower():
                    variants.append(cleaned)
            return variants[: self.n_queries]
        except Exception as exc:
            logger.warning(
                f"Multi-query generation failed, continuing with the original question only: {exc}"
            )
            return []

    def retrieve(self, question: str, top_k: int = None) -> List[RetrievedChunk]:
        """
        Runs hybrid retrieval for the original question plus up to
        n_queries LLM-generated paraphrases, then merges everything into
        one deduplicated candidate pool.

        Chunks surfaced by MULTIPLE query phrasings are a stronger
        relevance signal than raw similarity score alone, so they're sorted
        to the front of the returned list (ties broken by similarity
        score); the cross-encoder reranker downstream re-scores this whole
        pool anyway, so this ordering mainly matters if reranking is
        disabled.
        """
        queries = [question]
        if settings.enable_multi_query:
            variants = self._generate_query_variants(question)
            if variants:
                logger.info(
                    f"MQR expanded question into {len(variants)} additional quer(ies): {variants}"
                )
            queries.extend(variants)

        # key -> [best_chunk_seen, how_many_query_variants_returned_it]
        merged = {}

        for q in queries:
            for chunk in self.hybrid_retriever.retrieve(q, top_k=top_k):
                key = chunk.chunk_id or (chunk.source_file, chunk.page_number, chunk.text[:80])
                if key not in merged:
                    merged[key] = [chunk, 1]
                    continue

                existing_chunk, hit_count = merged[key]
                combined_methods = sorted(set(existing_chunk.retrieval_methods) | set(chunk.retrieval_methods))
                # Keep whichever instance had the stronger vector distance,
                # but always carry forward the union of retrieval methods.
                if chunk.similarity_score < existing_chunk.similarity_score:
                    chunk.retrieval_methods = combined_methods
                    merged[key] = [chunk, hit_count + 1]
                else:
                    existing_chunk.retrieval_methods = combined_methods
                    merged[key][1] = hit_count + 1

        ranked: List[Tuple[RetrievedChunk, int]] = sorted(
            merged.values(), key=lambda pair: (-pair[1], pair[0].similarity_score)
        )
        return [chunk for chunk, _hit_count in ranked]
