# ==============================================================================
# retrieval/reranker.py
# ------------------------------------------------------------------------------
# NEW MODULE — Cross-Encoder Reranker, the final precision pass before
# chunks are handed to the LLM.
#
# WHY A SEPARATE RERANKING STAGE:
#   Vector search and BM25 are both "bi-encoder" style: they score the
#   query and each document INDEPENDENTLY (embed the query once, embed
#   every document once, compare vectors/term-overlap). That's what makes
#   them fast enough to run over an entire corpus, but it also means
#   neither ever lets the query and a specific document actually interact
#   in the same computation.
#
#   A cross-encoder instead feeds (query, document) TOGETHER as one input
#   to a small transformer and outputs a single relevance score for that
#   exact pair. This produces a noticeably stronger relevance signal — but
#   it's far too slow to run against an entire corpus (it can't be
#   precomputed/indexed at all), so the standard pattern is:
#     cheap retrievers (BM25 + vector, fused via RRF, expanded via MQR)
#     narrow the corpus down to a small candidate pool (tens of chunks)
#                                |
#                                v
#     cross-encoder reranks ONLY that small pool -> final top-K
#
# MODEL CHOICE:
#   cross-encoder/ms-marco-MiniLM-L-6-v2 (the default here) is a small,
#   fast, widely-used general-purpose reranker trained on MS MARCO passage
#   ranking data — a good default that runs comfortably on CPU. It's
#   swappable via RERANKER_MODEL in .env without touching this file.
# ==============================================================================

from typing import List

from retrieval.retriever import RetrievedChunk
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class CrossEncoderReranker:
    """
    Re-scores a candidate pool of RetrievedChunk objects against the
    ORIGINAL user question using a cross-encoder model, then truncates to
    the final top-K that will actually be sent to the LLM.

    The model is lazy-loaded on first use (not in __init__) so importing
    this module, or constructing a reranker that ends up disabled via
    config, never pays the model-loading cost.
    """

    def __init__(self, model_name: str = None):
        self.model_name = model_name or settings.reranker_model
        self._model = None

    def _get_model(self):
        if self._model is None:
            from sentence_transformers import CrossEncoder

            logger.info(f"Loading cross-encoder reranker model '{self.model_name}'...")
            self._model = CrossEncoder(self.model_name)
            logger.info("Cross-encoder reranker model loaded")
        return self._model

    def rerank(
        self, question: str, candidates: List[RetrievedChunk], top_k: int = None
    ) -> List[RetrievedChunk]:
        """
        Args:
            question: the user's ORIGINAL question (not an MQR variant —
                      reranking should reflect exactly what the user asked).
            candidates: the fused candidate pool from HybridRetriever /
                        MultiQueryRetriever.
            top_k: final number of chunks to keep. Defaults to
                   settings.retrieval_top_k.

        Returns:
            The top_k candidates, ordered by cross-encoder relevance score
            (each chunk's `.rerank_score` is set as a side effect).
        """
        k = top_k or settings.retrieval_top_k
        if not candidates:
            return []

        if not settings.enable_reranker:
            logger.info("Reranker disabled (ENABLE_RERANKER=false) — using fused retrieval order")
            return candidates[:k]

        try:
            model = self._get_model()
            pairs = [(question, chunk.text) for chunk in candidates]
            scores = model.predict(pairs)
        except Exception as exc:
            logger.warning(
                f"Cross-encoder reranking failed ({exc}); falling back to pre-rerank retrieval order"
            )
            return candidates[:k]

        for chunk, score in zip(candidates, scores):
            chunk.rerank_score = float(score)

        reranked = sorted(candidates, key=lambda c: c.rerank_score, reverse=True)
        logger.info(
            f"Reranked {len(candidates)} candidate(s) -> keeping top {min(k, len(reranked))}"
        )
        return reranked[:k]
