# ==============================================================================
# retrieval/bm25_index.py
# ------------------------------------------------------------------------------
# NEW MODULE — sparse keyword retrieval half of Hybrid Retrieval.
#
# WHAT IS BM25? (GenAI beginners)
#   BM25 ("Best Matching 25") is a classic keyword-ranking algorithm — the
#   same family of technique behind traditional search engines before
#   embeddings existed. Given a query, it scores every document by how
#   often the query's exact terms appear in it, weighted so rare terms
#   count for more than common ones and long documents don't win just by
#   being long. Unlike vector search, it has no notion of "meaning" — it's
#   pure keyword overlap.
#
# WHY WE STILL WANT IT ALONGSIDE VECTOR SEARCH:
#   Insurance documents are full of exact tokens that MUST match precisely
#   to be useful — plan names, dollar figures, defined terms like
#   "coinsurance" vs. "co-payment", CPT/HCPCS-style codes, section numbers.
#   A dense embedding model can blur these together ("$250" and "$2,500"
#   can end up close in vector space); BM25 never confuses them. Combining
#   both (see retrieval/hybrid_retriever.py) covers each other's blind
#   spots.
#
# WHY A SEPARATE INDEX FROM CHROMA:
#   ChromaDB is a VECTOR database — it has no keyword/BM25 index built in.
#   So we maintain BM25's small in-memory index ourselves, built FROM the
#   exact same chunks already stored in Chroma (via
#   ChromaManager.get_all_documents()), and persist it to disk so it
#   doesn't have to be rebuilt from scratch on every process restart.
# ==============================================================================

import os
import pickle
import re
from typing import List, Optional, Tuple

from langchain_core.documents import Document
from rank_bm25 import BM25Okapi

from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)

_TOKEN_RE = re.compile(r"[A-Za-z0-9$%]+")


def _tokenize(text: str) -> List[str]:
    """
    Minimal, dependency-free tokenizer: lowercase, split on non-alphanumeric
    boundaries, but keep '$' and '%' attached to adjacent digits so dollar
    amounts and percentages ("$1,500", "20%") survive as meaningful tokens
    instead of being stripped down to bare numbers.
    """
    return [t.lower() for t in _TOKEN_RE.findall(text)]


class BM25Index:
    """
    Wraps rank_bm25.BM25Okapi and keeps each corpus entry's chunk_id and
    metadata alongside its score, so results can be merged with vector
    search results by the SAME chunk_id used in ChromaDB (see
    hybrid_retriever.py).
    """

    def __init__(self):
        self._bm25: Optional[BM25Okapi] = None
        self._ids: List[str] = []
        self._texts: List[str] = []
        self._metadatas: List[dict] = []

    @property
    def is_built(self) -> bool:
        return self._bm25 is not None and self.size > 0

    @property
    def size(self) -> int:
        return len(self._ids)

    def build(self, documents: List[Tuple[str, Document]]) -> None:
        """
        Args:
            documents: (chunk_id, Document) pairs — normally straight from
                       ChromaManager.get_all_documents(), so the BM25
                       corpus always mirrors what's actually in the vector
                       store.
        """
        self._ids = [chunk_id for chunk_id, _ in documents]
        self._texts = [doc.page_content for _, doc in documents]
        self._metadatas = [doc.metadata for _, doc in documents]

        if not self._texts:
            self._bm25 = None
            logger.warning("BM25Index.build() called with no documents — index left empty")
            return

        tokenized_corpus = [_tokenize(t) for t in self._texts]
        self._bm25 = BM25Okapi(tokenized_corpus)
        logger.info(f"BM25 index built with {len(self._ids)} document(s)")

    def search(self, query: str, top_k: int) -> List[dict]:
        """
        Returns up to top_k results as dicts with keys: chunk_id, text,
        metadata, score (higher = more relevant). Results with a
        non-positive score (no keyword overlap at all) are dropped, since a
        zero-overlap BM25 "match" isn't a real signal and would otherwise
        pollute Reciprocal Rank Fusion with noise.
        """
        if not self.is_built:
            return []

        scores = self._bm25.get_scores(_tokenize(query))
        ranked_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)

        results = []
        for idx in ranked_indices[:top_k]:
            if scores[idx] <= 0:
                continue
            results.append(
                {
                    "chunk_id": self._ids[idx],
                    "text": self._texts[idx],
                    "metadata": self._metadatas[idx],
                    "score": float(scores[idx]),
                }
            )
        return results

    def save(self, path: str = None) -> None:
        """Persist the corpus to disk so it survives a process restart."""
        path = path or settings.bm25_index_path
        directory = os.path.dirname(path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        with open(path, "wb") as f:
            pickle.dump(
                {"ids": self._ids, "texts": self._texts, "metadatas": self._metadatas}, f
            )
        logger.info(f"BM25 index persisted to '{path}' ({self.size} documents)")

    def load(self, path: str = None) -> bool:
        """
        Restore a previously-saved index. Returns True on success, False if
        no saved index exists yet (e.g. first run before any ingestion).
        """
        path = path or settings.bm25_index_path
        if not os.path.exists(path):
            return False

        with open(path, "rb") as f:
            data = pickle.load(f)

        self._ids = data.get("ids", [])
        self._texts = data.get("texts", [])
        self._metadatas = data.get("metadatas", [])

        if self._texts:
            self._bm25 = BM25Okapi([_tokenize(t) for t in self._texts])
        else:
            self._bm25 = None

        logger.info(f"BM25 index loaded from '{path}' ({self.size} documents)")
        return self.is_built
