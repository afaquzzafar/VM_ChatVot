# ==============================================================================
# retrieval/hybrid_retriever.py
# ------------------------------------------------------------------------------
# NEW MODULE — Hybrid Retrieval: BM25 (sparse/keyword) + vector (dense)
# search, fused with Reciprocal Rank Fusion (RRF).
#
# WHY HYBRID RETRIEVAL:
#   Vector search is great at matching MEANING ("how much do I pay before
#   coverage kicks in" -> "deductible") but can blur together text that
#   differs in exact wording that actually matters — dollar amounts, plan
#   names, defined terms like "coinsurance" vs. "co-payment". BM25 (see
#   retrieval/bm25_index.py) is the opposite: exact keyword match, no
#   notion of paraphrase. Combining both consistently retrieves better than
#   either alone on jargon-heavy domain documents like insurance plans.
#
# WHY RECIPROCAL RANK FUSION (RRF):
#   Chroma's vector distance and BM25's term-frequency score are on
#   different, incomparable scales, so averaging them directly is
#   meaningless without careful per-query normalization. RRF fuses on RANK
#   POSITION instead:
#
#       rrf_score(doc) = sum over each retriever R that returned doc of
#                         1 / (k + rank_of_doc_in_R)
#
#   A doc that ranks highly in EITHER retriever (or, best of all, both)
#   gets a high fused score, with no scale-matching required. k (default
#   60) is a standard damping constant from the original RRF paper that
#   keeps a rank-1 result from completely dominating over everything else.
#
# HOW THIS FITS INTO THE BIGGER PICTURE:
#   This module replaces retrieval/retriever.py's plain vector-only
#   Retriever as the FIRST stage of question-answering. Its output then
#   feeds retrieval/reranker.py, which re-scores the fused candidate pool
#   with a cross-encoder for the final top-K used in the LLM prompt.
# ==============================================================================

from typing import List, Optional

from retrieval.bm25_index import BM25Index
from retrieval.retriever import RetrievedChunk
from vectorstore.chroma_manager import ChromaManager
from utils.config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


class HybridRetriever:
    """
    Runs vector search and BM25 keyword search for the same query, then
    fuses their ranked result lists into one candidate pool via Reciprocal
    Rank Fusion. If BM25 is disabled or its index is empty (e.g. right
    after startup before ingestion has run), this degrades gracefully to
    vector-only search rather than failing.
    """

    def __init__(self, chroma_manager: ChromaManager, bm25_index: Optional[BM25Index] = None):
        self.chroma_manager = chroma_manager
        self.bm25_index = bm25_index or BM25Index()
        # Try to pick up a previously-persisted BM25 index immediately, so a
        # fresh process restart doesn't silently run vector-only until the
        # next ingestion call rebuilds it.
        self.bm25_index.load()

    def refresh_bm25_index(self) -> None:
        """
        Rebuild (and persist) the BM25 keyword index from whatever chunks
        are currently stored in Chroma. Call this once after every
        ingestion run (see rag/rag_pipeline.py), since BM25 has no way to
        incrementally learn about newly-added documents on its own.
        """
        documents = self.chroma_manager.get_all_documents()
        self.bm25_index.build(documents)
        if self.bm25_index.is_built:
            self.bm25_index.save()

    def retrieve(self, query: str, top_k: int = None) -> List[RetrievedChunk]:
        """
        Args:
            query: a single search string (the original question, or one
                   variant produced by Multi-Query Retrieval).
            top_k: how many fused candidates to return. Defaults to
                   settings.rerank_candidate_pool when reranking is
                   enabled (a wider pool for the reranker to work with),
                   otherwise settings.retrieval_top_k.

        Returns:
            RetrievedChunk objects ordered by fused RRF score, richest
            match first.
        """
        pool_size = top_k or (
            settings.rerank_candidate_pool if settings.enable_reranker else settings.retrieval_top_k
        )
        candidate_k = max(pool_size * settings.hybrid_candidate_multiplier, pool_size)

        # --- Dense: vector similarity search (always runs) -----------------
        vector_hits = self.chroma_manager.similarity_search_with_scores_and_ids(
            query, top_k=candidate_k
        )
        # vector_hits: list of (chunk_id, Document, distance) — LOWER distance
        # means MORE similar, so rank order is already correct as returned.

        # --- Sparse: BM25 keyword search (skipped if disabled/empty) -------
        bm25_hits: List[dict] = []
        if settings.enable_hybrid_retrieval and self.bm25_index.is_built:
            bm25_hits = self.bm25_index.search(query, candidate_k)
        elif settings.enable_hybrid_retrieval:
            logger.info("Hybrid retrieval enabled but BM25 index is empty — falling back to vector-only")

        # --- Fuse via Reciprocal Rank Fusion --------------------------------
        rrf_k = settings.rrf_k
        fused_scores = {}
        chunk_lookup = {}
        methods_by_id = {}

        for rank, (chunk_id, document, distance) in enumerate(vector_hits):
            fused_scores[chunk_id] = fused_scores.get(chunk_id, 0.0) + 1.0 / (rrf_k + rank + 1)
            chunk_lookup[chunk_id] = (document.page_content, document.metadata, float(distance))
            methods_by_id.setdefault(chunk_id, set()).add("vector")

        for rank, hit in enumerate(bm25_hits):
            chunk_id = hit["chunk_id"]
            fused_scores[chunk_id] = fused_scores.get(chunk_id, 0.0) + 1.0 / (rrf_k + rank + 1)
            chunk_lookup.setdefault(chunk_id, (hit["text"], hit["metadata"], None))
            methods_by_id.setdefault(chunk_id, set()).add("bm25")

        ranked_ids = sorted(fused_scores, key=lambda cid: fused_scores[cid], reverse=True)[:pool_size]

        retrieved: List[RetrievedChunk] = []
        for chunk_id in ranked_ids:
            text, metadata, distance = chunk_lookup[chunk_id]
            retrieved.append(
                RetrievedChunk(
                    text=text,
                    source_file=metadata.get("source", "unknown"),
                    page_number=metadata.get("page", 0),
                    # Fall back to the (unitless) fused RRF score when a
                    # chunk was only surfaced by BM25 and has no vector
                    # distance of its own.
                    similarity_score=distance if distance is not None else -fused_scores[chunk_id],
                    chunk_id=chunk_id,
                    retrieval_methods=sorted(methods_by_id.get(chunk_id, [])),
                    section=metadata.get("section"),
                    subsection=metadata.get("subsection"),
                )
            )

        logger.info(
            f"Hybrid retrieve('{query[:60]}...'): {len(vector_hits)} vector hit(s), "
            f"{len(bm25_hits)} BM25 hit(s) -> {len(retrieved)} fused candidate(s)"
        )
        return retrieved

    def has_documents(self) -> bool:
        """Whether any documents have been ingested/indexed yet."""
        return self.chroma_manager.document_count() > 0
